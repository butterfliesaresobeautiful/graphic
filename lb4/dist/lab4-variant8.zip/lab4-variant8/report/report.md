# Титульный лист

Минобрнауки России

Юго-Западный государственный университет

Кафедра программной инженерии

ОТЧЁТ

по лабораторной работе № 4

по дисциплине «Компьютерная графика»

«Растеризация окружностей»

Индивидуальный номер 28. Вариант 8

Выполнил: студент группы __________

ФИО ____________________________

Проверил: _______________________

Курск 2026 г.

# 1 Задание

## Цель работы

изучение алгоритмов растеризации окружностей, создание программы для визуализации работы алгоритмов.

Источник: Ефремов В. В., Ефремова И. Н., Петрик Е. А. Компьютерная графика: введение в обработку изображений: практикум. Курск: ЮЗГУ, 2024. ЛБ4: с. 64–84; цель: с. 64; задание и отчёт: с. 71–72; варианты: с. 72–73; вопросы: с. 73. Страницы приложены к комплекту.

Максимальный номер индивидуального варианта — 20. По заданной схеме 28 % 20 = 8. Формулировка варианта 8: «Вывести треугольник Рёло заданной ширины». Для каждой дуги необходимо вычислить координаты центра, радиус и границы углов.

Общее задание требует реализовать построение по уравнению окружности, по параметрическому уравнению, по алгоритму Брезенхема и готовыми графическими средствами, затем проиллюстрировать различия результатов либо их отсутствие. Координаты центра и радиус должны задаваться пользователем. Порядок выполнения дополнительно предусматривает чтение файла изображения и запись результата. Необходимо представить схемы алгоритмов, полный листинг, пример работы и ответы на четыре контрольных вопроса.

Разработано настольное приложение на Go. Пользователь задаёт ширину треугольника Рёло и положение его центра. Радиусы трёх дуг определяются шириной; отдельный режим окружности позволяет независимо задавать её центр и радиус. В качестве холста используется белое изображение или загруженный файл PNG/JPEG/GIF. Результаты четырёх методов показаны отдельно, доступны наложение, карта различий, увеличение пикселей и сохранение PNG.

# 2 Схемы алгоритмов

## 2.1 Геометрическое построение

Треугольник Рёло — выпуклая фигура постоянной ширины. Он является пересечением трёх дисков одинакового радиуса w, центры которых находятся в вершинах равностороннего треугольника со стороной w. Граница состоит из трёх меньших дуг по 60°. Таким образом, вводимая ширина одновременно равна стороне исходного треугольника и радиусу каждой дуги, но не радиусу описанной окружности исходного треугольника.

Используется экранная система координат: X направлена вправо, Y — вниз. Пользовательские x₀, y₀ задают центроид исходного равностороннего треугольника. Для положения вершиной вверх координаты его вершин определяются формулами:

A = (x₀; y₀ − w/√3),

B = (x₀ − w/2; y₀ + w/(2√3)),

C = (x₀ + w/2; y₀ + w/(2√3)).

Угол отсчитывается от положительного направления X по часовой стрелке. Дуга с центром A проходит от C до B при углах 60…120°; дуга с центром B — от A до C при 300…360°; дуга с центром C — от B до A при 180…240°. Все три радиуса равны w. При x₀ = 320, y₀ = 240, w = 280 получаем A ≈ (320; 78,341925), B ≈ (180; 320,829038), C ≈ (460; 320,829038).

Для любой ориентации параллельных опорных прямых расстояние между ними равно w в непрерывной геометрии. Растр приближает эту границу с погрешностью округления. Проверка геометрии отдельно измеряет ширину по плотным отсчётам дуг для 180 направлений; допуск составляет 0,001 пикселя и не смешивается с погрешностью самого растра.

Рисунок 1 — Геометрия варианта 8: три дуги и исходный равносторонний треугольник

![Рисунок 1 — Геометрия варианта 8: три дуги и исходный равносторонний треугольник](geometry.png)

## 2.2 Построение по уравнению окружности

x² + y² = R²,   y = round(√(R² − x²)).

Для локального центра (0;0) перебираются целые x от нуля до ceil(R/√2), пока вычисленное округлённое y удовлетворяет условию x ≤ y. Точка отражается в восемь октантов: (±x; ±y), (±y; ±x). Граница ceil нужна, чтобы не потерять диагональную точку при округлении: например, для R = 7 необходимо включить (5;5). Обработка только октанта устраняет большие скачки ординаты, возникающие при проходе всей четверти с шагом по X, описанные на с. 64.

Для каждой симметричной точки через atan2 определяется принадлежность угловому диапазону дуги. Затем прибавляются вещественные координаты центра, результат округляется к целому пикселю и проверяется попадание в холст. В восьмикратной симметрии некоторые точки совпадают; булева маска хранит каждую позицию один раз. Общие концы неполных дуг добавляются явно по округлённым координатам вершин.

## 2.3 Параметрическое построение

x = cx + R cos t,   y = cy + R sin t.

N = max(1, ceil(Rβπ/180)),   tₖ = (α + βk/N)π/180,   k = 0…N.

Здесь α — начальный угол дуги в градусах, β — её угловая длина. Число интервалов N выбирается так, чтобы шаг по длине дуги не превышал одного пикселя. Оба конца включены. Округлённые соседние точки соединяются целочисленным алгоритмом отрезка, как предлагается в теоретическом описании на с. 65. В отличие от выбора одного пикселя по критерию ошибки, параметрическое семплирование может создавать больше соседних пикселей и иную лестницу контура.

## 2.4 Алгоритм Брезенхема

Использована целочисленная восьмиоктантная форма алгоритма с начальной точкой x = 0, y = R и параметром d = 3 − 2R. Сначала выводятся симметричные точки, попавшие в углы дуги, затем выбирается горизонтальный или диагональный шаг. На каждом шаге X увеличивается на единицу, Y либо сохраняется, либо уменьшается на единицу. Цикл завершается при x > y.

Если d < 0:   dнов = d + 4x + 6,   yнов = y.

Иначе:   dнов = d + 4(x − y) + 10,   yнов = y − 1.

В обоих случаях:   xнов = x + 1.

В правых частях используются старые x, y. Параметр решения связан с неявной функцией окружности F(x,y) = x² + y² − R²: d = 2F(x + 1, y − 1/2) + 1/2. Эквивалентная целочисленная запись d = 2(x + 1)² + 2y² − 2y + 1 − 2R² проверяется тестом для каждой итерации. При d < 0 средняя точка лежит внутри окружности и выбирается горизонтальный шаг; иначе — диагональный. Это форма Брезенхема для одного октанта с последующим отражением.

Генерация локальной окружности использует только целочисленные сложения, умножение на малые константы и сравнения. Отбор дуг по углам и перенос к вещественным центрам вынесены отдельно и используют вещественную арифметику. Поэтому утверждение о целочисленности относится к ядру Брезенхема, а не ко всей программе построения треугольника Рёло.

## 2.5 Готовый примитив и сравнение

В стандартной библиотеке Go нет готовой функции рисования окружности. Поэтому четвёртый способ реализован встроенным примитивом графической системы X11 PolyArc, вызванным из Go через библиотеку xgb. Это функциональный аналог готового TCanvas.Arc из примера методички. Примитив выполняется самим X-сервером на отдельном растре; его результат считывается для сравнения. Он не подменяется собственной реализацией одного из первых трёх методов.

Четвёртый способ создаёт чёрный Pixmap на X-сервере и выводит белые дуги командой PolyArc. Используется нулевая ширина линии X11, означающая тонкую растровую линию без сглаживания. Ограничивающий квадрат имеет сторону 2R. Координаты центров предварительно округляются до целых; углы передаются в единицах 1/64 градуса. Положительное направление углов X11 противоположно экранному, поэтому знаки начального угла и длины дуги меняются.

Округлённые общие вершины добавляются командой PolyPoint тем же способом, что и в собственных алгоритмах. Полученная маска считывается через GetImage. Особенности округления центра и реализации X-сервера могут влиять на конкретный набор граничных пикселей; измеренное совпадение на демонстрационном примере не утверждается для любых параметров и серверов.

Все методы формируют отдельные булевы маски, независимо от цвета загруженного фона. Поэтому чёрный пиксель исходного изображения не считается автоматически частью контура. Для каждой маски подсчитываются уникальные пиксели, затем вычисляются попарные симметрические разности (XOR), пересечение и объединение всех четырёх масок. На карте различий красным отмечены позиции, принадлежащие некоторым, но не всем маскам; общие позиции серые. На наложении общие позиции чёрные, остальные используют средний цвет присутствующих методов.

Dᵢⱼ = |Mᵢ △ Mⱼ|;   Nразл = |M₁ ∪ M₂ ∪ M₃ ∪ M₄| − |M₁ ∩ M₂ ∩ M₃ ∩ M₄|.

Цвета методов на наложении: синий — уравнение, оранжевый — параметрическое, зелёный — Брезенхем, фиолетовый — X11. Для точного сравнения используются численные маски и карта различий, поскольку смешанные цвета не кодируют уникально все сочетания. Сохранённые контуры не сглаживаются. Уменьшенные экранные превью фильтруются для сохранения видимости тонких линий, а увеличение использует ближайшего соседа. Для проверки пикселей предусмотрен отдельный вид.

Сложность каждого собственного метода одной окружности составляет O(R), трёх дуг — O(w). Полное сравнение масок требует O(WH); память расходуется на маски и результирующие RGB-изображения. Лимиты: стороны холста 1…4096, площадь до 16 000 000 пикселей, входной файл до 32 МиБ, ширина и радиус 1…2048, координаты центра от −4096 до 4096. Выход за границы обрезается; полностью невидимая фигура даёт пустой контур, а не обращение за пределы памяти.

Рисунок 2 — Общий алгоритм построения и сравнения

![Рисунок 2 — Общий алгоритм построения и сравнения](algorithm-main.png)

Рисунок 3 — Построение одной дуги по уравнению окружности

![Рисунок 3 — Построение одной дуги по уравнению окружности](algorithm-equation.png)

Рисунок 4 — Параметрическое построение одной дуги

![Рисунок 4 — Параметрическое построение одной дуги](algorithm-parametric.png)

Рисунок 5 — Построение одной дуги по алгоритму Брезенхема

![Рисунок 5 — Построение одной дуги по алгоритму Брезенхема](algorithm-bresenham.png)

# 3 Листинг программы

Приведён полный собственный код Go, включая математическую часть, ввод-вывод изображений, обращение к готовому примитиву X11, настольный интерфейс, консольный режим и тесты. Зависимости xgb, x/image и x/text зафиксированы в go.mod/go.sum и поставляются с исходниками и лицензиями в vendor. Их исходный код в листингах не дублируется. Шрифт интерфейса встроен в исполняемый файл. Скрипты Python в tools служат только для оформления и упаковки отчёта.

## Листинг 3.1 — go.mod

```go
module graphiclabs/lb4

go 1.22

require (
	github.com/jezek/xgb v1.1.1
	golang.org/x/image v0.24.0
)

require golang.org/x/text v0.22.0 // indirect
```

## Листинг 3.2 — cmd/lab4/main.go

```go
package main

import (
	"errors"
	"flag"
	"fmt"
	"graphiclabs/lb4/internal/desktop"
	"graphiclabs/lb4/internal/raster"
	"image"
	"os"
	"path/filepath"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "Ошибка:", err)
		os.Exit(1)
	}
}
func run(args []string) error {
	c := raster.Default()
	f := flag.NewFlagSet("lab4", flag.ContinueOnError)
	mode := f.String("mode", "gui", "gui: настольное окно; batch: сохранить результаты (тоже нужен X11)")
	source := f.String("source", "", "фон PNG/JPEG/GIF; по умолчанию белый холст")
	out := f.String("out", "output", "каталог результатов")
	shape := f.String("shape", "reuleaux", "reuleaux или circle")
	f.IntVar(&c.Size, "size", c.Size, "ширина треугольника Рёло")
	f.IntVar(&c.Radius, "radius", c.Radius, "радиус в режиме circle")
	f.IntVar(&c.CX, "cx", c.CX, "X центра фигуры / центроида исходного треугольника")
	f.IntVar(&c.CY, "cy", c.CY, "Y центра фигуры / центроида исходного треугольника")
	f.IntVar(&c.Width, "width", c.Width, "ширина белого холста")
	f.IntVar(&c.Height, "height", c.Height, "высота белого холста")
	if err := f.Parse(args); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return nil
		}
		return err
	}
	if f.NArg() != 0 {
		return errors.New("неожиданные позиционные аргументы")
	}
	if *mode != "gui" && *mode != "batch" {
		return errors.New("режим: gui или batch")
	}
	if *shape != "reuleaux" && *shape != "circle" {
		return errors.New("фигура: reuleaux или circle")
	}
	c.Circle = *shape == "circle"
	var src *image.RGBA
	var err error
	if *source != "" {
		src, err = raster.Load(*source)
		if err != nil {
			return err
		}
		c.Width, c.Height = src.Rect.Dx(), src.Rect.Dy()
	} else {
		src, err = raster.New(c.Width, c.Height)
		if err != nil {
			return err
		}
	}
	if err = c.Validate(); err != nil {
		return err
	}
	if *mode == "gui" {
		if *out == "output" {
			exe, err := os.Executable()
			if err != nil {
				return err
			}
			base := filepath.Dir(exe)
			if filepath.Base(base) == "bin" {
				base = filepath.Dir(base)
			}
			*out = filepath.Join(base, "output")
		}
		return desktop.Run(src, *source, *out, c)
	}
	r, err := desktop.Process(src, c)
	if err != nil {
		return err
	}
	if err = r.SaveAll(*out, *source); err != nil {
		return err
	}
	fmt.Printf("ЛБ4: 28 %% 20 = 8. Сохранено: %s\nПикселей: %v; общих: %d; различающихся: %d\n", *out, r.Metrics.Pixels, r.Metrics.Common, r.Metrics.Different)
	return nil
}
```

## Листинг 3.3 — internal/raster/geometry.go

```go
package raster

import (
	"errors"
	"image"
	"math"
)

// Config uses screen coordinates: X right, Y down. Size is the Reuleaux width.
type Config struct {
	Width, Height        int
	CX, CY, Size, Radius int
	Circle               bool
}
type Point struct{ X, Y float64 }
type Arc struct {
	Center       Point
	Radius       int
	Start, Sweep float64
}

func Default() Config { return Config{640, 480, 320, 240, 280, 140, false} }
func (c Config) Validate() error {
	if err := Dimensions(c.Width, c.Height); err != nil {
		return err
	}
	if c.Size < 1 || c.Size > 2048 || c.Radius < 1 || c.Radius > 2048 {
		return errors.New("ширина и радиус: целые числа 1…2048")
	}
	if c.CX < -4096 || c.CX > 4096 || c.CY < -4096 || c.CY > 4096 {
		return errors.New("координаты центра: −4096…4096")
	}
	return nil
}
func (c Config) Vertices() [3]Point {
	x, y, w := float64(c.CX), float64(c.CY), float64(c.Size)
	return [3]Point{{x, y - w/math.Sqrt(3)}, {x - w/2, y + w/(2*math.Sqrt(3))}, {x + w/2, y + w/(2*math.Sqrt(3))}}
}
func (c Config) Arcs() []Arc {
	if c.Circle {
		return []Arc{{Point{float64(c.CX), float64(c.CY)}, c.Radius, 0, 360}}
	}
	v := c.Vertices()
	return []Arc{{v[0], c.Size, 60, 60}, {v[1], c.Size, 300, 60}, {v[2], c.Size, 180, 60}}
}
func (a Arc) At(degrees float64) Point {
	t := degrees * math.Pi / 180
	return Point{a.Center.X + float64(a.Radius)*math.Cos(t), a.Center.Y + float64(a.Radius)*math.Sin(t)}
}
func (a Arc) Contains(x, y int) bool {
	if a.Sweep >= 360 {
		return true
	}
	t := math.Atan2(float64(y), float64(x)) * 180 / math.Pi
	d := math.Mod(t-a.Start+720, 360)
	return d <= a.Sweep+1e-9
}
func (c Config) ZoomRect() image.Rectangle {
	a := c.Arcs()[0]
	angle := 90.0
	if c.Circle {
		angle = 45
	} else {
		a = c.Arcs()[1]
		angle = 330
	}
	p := a.At(angle)
	x, y := int(math.Round(p.X)), int(math.Round(p.Y))
	return image.Rect(x-16, y-16, x+16, y+16)
}
```

## Листинг 3.4 — internal/raster/circle.go

```go
package raster

import (
	"image"
	"math"
)

// Mask is independent of background colour, so comparison never confuses a
// source pixel with a contour pixel. Clipping occurs only in Set.
type Mask struct {
	W, H    int
	Bits    []bool
	Clipped int
}

func NewMask(w, h int) *Mask { return &Mask{W: w, H: h, Bits: make([]bool, w*h)} }
func (m *Mask) Set(x, y int) {
	if x < 0 || y < 0 || x >= m.W || y >= m.H {
		m.Clipped++
		return
	}
	m.Bits[y*m.W+x] = true
}
func (m *Mask) At(x, y int) bool { return x >= 0 && y >= 0 && x < m.W && y < m.H && m.Bits[y*m.W+x] }
func (m *Mask) Count() int {
	n := 0
	for _, v := range m.Bits {
		if v {
			n++
		}
	}
	return n
}
func (m *Mask) point(p Point) { m.Set(int(math.Round(p.X)), int(math.Round(p.Y))) }
func (m *Mask) symmetric(a Arc, x, y int) {
	for _, p := range [8]image.Point{{x, y}, {y, x}, {-x, y}, {-y, x}, {x, -y}, {y, -x}, {-x, -y}, {-y, -x}} {
		if a.Contains(p.X, p.Y) {
			m.point(Point{a.Center.X + float64(p.X), a.Center.Y + float64(p.Y)})
		}
	}
}

// Equation evaluates one octant and uses eightfold symmetry. Restricting x<=y
// avoids the large slope / missing-pixel issue of scanning an entire quadrant.
func Equation(m *Mask, a Arc) {
	r := float64(a.Radius)
	for x := 0; float64(x) <= math.Ceil(r/math.Sqrt2); x++ {
		y := int(math.Round(math.Sqrt(r*r - float64(x*x))))
		if x > y {
			break
		}
		m.symmetric(a, x, y)
	}
	endpoints(m, a)
}

// Step records the integer decision variable before a Bresenham iteration.
type Step struct{ X, Y, D int }

func Trace(radius int) []Step {
	x, y, d := 0, radius, 3-2*radius
	steps := make([]Step, 0, radius+1)
	for x <= y {
		steps = append(steps, Step{x, y, d})
		if d < 0 {
			d += 4*x + 6
		} else {
			d += 4*(x-y) + 10
			y--
		}
		x++
	}
	return steps
}
func Bresenham(m *Mask, a Arc) {
	for _, s := range Trace(a.Radius) {
		m.symmetric(a, s.X, s.Y)
	}
	endpoints(m, a)
}

// line joins neighbouring parametric samples; no external rasteriser is used.
func line(m *Mask, a, b image.Point) {
	dx, dy := abs(b.X-a.X), -abs(b.Y-a.Y)
	sx, sy := -1, -1
	if a.X < b.X {
		sx = 1
	}
	if a.Y < b.Y {
		sy = 1
	}
	err := dx + dy
	for {
		m.Set(a.X, a.Y)
		if a == b {
			return
		}
		e := 2 * err
		if e >= dy {
			err += dy
			a.X += sx
		}
		if e <= dx {
			err += dx
			a.Y += sy
		}
	}
}
func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
func Parametric(m *Mask, a Arc) {
	// Uniform arc-length step <= 1 pixel, with both endpoints included.
	n := max(1, int(math.Ceil(a.Sweep*math.Pi/180*float64(a.Radius))))
	var prev image.Point
	for k := 0; k <= n; k++ {
		p := a.At(a.Start + a.Sweep*float64(k)/float64(n))
		cur := image.Pt(int(math.Round(p.X)), int(math.Round(p.Y)))
		if k == 0 {
			m.Set(cur.X, cur.Y)
		} else {
			line(m, prev, cur)
		}
		prev = cur
	}
}
func endpoints(m *Mask, a Arc) {
	if a.Sweep < 360 {
		m.point(a.At(a.Start))
		m.point(a.At(a.Start + a.Sweep))
	}
}
func Custom(c Config) ([3]*Mask, error) {
	var masks [3]*Mask
	if err := c.Validate(); err != nil {
		return masks, err
	}
	fs := []func(*Mask, Arc){Equation, Parametric, Bresenham}
	for i, f := range fs {
		masks[i] = NewMask(c.Width, c.Height)
		for _, a := range c.Arcs() {
			f(masks[i], a)
		}
	}
	return masks, nil
}
```

## Листинг 3.5 — internal/raster/image.go

```go
// Package raster implements the RGB file operations for lab 4.
package raster

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"image/color"
	_ "image/gif"
	_ "image/jpeg"
	"image/png"
	"io"
	"os"
	"path/filepath"
)

const MaxSide = 4096
const MaxPixels = 16_000_000
const MaxFile = 32 << 20

func Dimensions(w, h int) error {
	if w < 1 || h < 1 || w > MaxSide || h > MaxSide || w*h > MaxPixels {
		return fmt.Errorf("размеры: 1…%d, не более %d пикселей", MaxSide, MaxPixels)
	}
	return nil
}

// New returns an opaque white canvas, including every boundary pixel.
func New(w, h int) (*image.RGBA, error) {
	if err := Dimensions(w, h); err != nil {
		return nil, err
	}
	m := image.NewRGBA(image.Rect(0, 0, w, h))
	for i := range m.Pix {
		m.Pix[i] = 255
	}
	return m, nil
}

// Decode limits input and allocation before decoding. Transparency is composed
// over white; opaque RGB values are unchanged. GIF uses its first frame.
func Decode(r io.Reader) (*image.RGBA, error) {
	data, err := io.ReadAll(io.LimitReader(r, MaxFile+1))
	if err != nil {
		return nil, err
	}
	if len(data) > MaxFile {
		return nil, errors.New("файл больше 32 МиБ")
	}
	cfg, _, err := image.DecodeConfig(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("ожидается PNG, JPEG или GIF: %w", err)
	}
	if err = Dimensions(cfg.Width, cfg.Height); err != nil {
		return nil, err
	}
	src, _, err := image.Decode(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("повреждённое изображение: %w", err)
	}
	dst, _ := New(cfg.Width, cfg.Height)
	for y := 0; y < cfg.Height; y++ {
		for x := 0; x < cfg.Width; x++ {
			r, g, b, a := src.At(x+src.Bounds().Min.X, y+src.Bounds().Min.Y).RGBA()
			dst.SetRGBA(x, y, color.RGBA{
				uint8((r + 65535 - a) >> 8),
				uint8((g + 65535 - a) >> 8),
				uint8((b + 65535 - a) >> 8), 255,
			})
		}
	}
	return dst, nil
}

func Load(path string) (*image.RGBA, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("открытие: %w", err)
	}
	defer f.Close()
	return Decode(f)
}

// Save writes PNG atomically; a failed encode does not truncate an old result.
func Save(path string, m image.Image) error {
	if m == nil {
		return errors.New("нет изображения для сохранения")
	}
	f, err := os.CreateTemp(filepath.Dir(path), ".lab4-*.tmp")
	if err != nil {
		return fmt.Errorf("создание файла: %w", err)
	}
	defer os.Remove(f.Name())
	if err = png.Encode(f, m); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(f.Name(), path)
}
```

## Листинг 3.6 — internal/raster/results.go

```go
package raster

import (
	"encoding/json"
	"errors"
	"image"
	"image/color"
	"image/draw"
	"os"
	"path/filepath"
)

var Names = [4]string{"equation", "parametric", "bresenham", "native"}

type Metrics struct {
	Config                   Config
	MethodNames              [4]string
	Pixels                   [4]int
	PairwiseXOR              [4][4]int
	Common, Union, Different int
	NativePrimitive          string
}
type Results struct {
	Images                    [4]*image.RGBA
	Overlay, Difference, Zoom *image.RGBA
	Masks                     [4]*Mask
	Metrics                   Metrics
}

func Compose(background *image.RGBA, c Config, masks [4]*Mask) (Results, error) {
	r := Results{Masks: masks, Metrics: Metrics{Config: c, MethodNames: Names, NativePrimitive: "X11 PolyArc; line width 0; no antialiasing"}}
	if background == nil || background.Rect != image.Rect(0, 0, c.Width, c.Height) {
		return r, errors.New("фон должен соответствовать размерам холста")
	}
	for _, m := range masks {
		if m == nil || m.W != c.Width || m.H != c.Height {
			return r, errors.New("неверный размер маски")
		}
	}
	for i, m := range masks {
		r.Images[i], _ = New(c.Width, c.Height)
		draw.Draw(r.Images[i], background.Rect, background, image.Point{}, draw.Src)
		r.Metrics.Pixels[i] = m.Count()
	}
	r.Overlay, _ = New(c.Width, c.Height)
	r.Difference, _ = New(c.Width, c.Height)
	palette := [4]color.RGBA{{30, 95, 210, 255}, {220, 115, 0, 255}, {0, 140, 90, 255}, {150, 55, 190, 255}}
	black := color.RGBA{0, 0, 0, 255}
	for y := 0; y < c.Height; y++ {
		for x := 0; x < c.Width; x++ {
			n := 0
			sum := [3]int{}
			for i, m := range masks {
				if m.At(x, y) {
					r.Images[i].SetRGBA(x, y, black)
					n++
					sum[0] += int(palette[i].R)
					sum[1] += int(palette[i].G)
					sum[2] += int(palette[i].B)
				}
			}
			if n > 0 {
				r.Metrics.Union++
				r.Overlay.SetRGBA(x, y, color.RGBA{uint8(sum[0] / n), uint8(sum[1] / n), uint8(sum[2] / n), 255})
			}
			if n == 4 {
				r.Metrics.Common++
				r.Overlay.SetRGBA(x, y, black)
				r.Difference.SetRGBA(x, y, color.RGBA{180, 180, 180, 255})
			} else if n > 0 {
				r.Metrics.Different++
				r.Difference.SetRGBA(x, y, color.RGBA{220, 35, 50, 255})
			}
			for i := 0; i < 4; i++ {
				for j := 0; j < 4; j++ {
					if masks[i].At(x, y) != masks[j].At(x, y) {
						r.Metrics.PairwiseXOR[i][j]++
					}
				}
			}
		}
	}
	r.Zoom = Zoom(c, masks)
	return r, nil
}

// Zoom shows the same 32x32 crop for all four methods, using 8x pixel cells.
func Zoom(c Config, m [4]*Mask) *image.RGBA {
	dst, _ := New(528, 528)
	region := c.ZoomRect()
	for i, mask := range m {
		ox, oy := (i%2)*272, (i/2)*272
		for y := 0; y < 32; y++ {
			for x := 0; x < 32; x++ {
				col := color.RGBA{245, 247, 250, 255}
				if mask.At(region.Min.X+x, region.Min.Y+y) {
					col = color.RGBA{30, 45, 65, 255}
				}
				draw.Draw(dst, image.Rect(ox+x*8, oy+y*8, ox+x*8+7, oy+y*8+7), image.NewUniform(col), image.Point{}, draw.Src)
			}
		}
	}
	return dst
}

// SaveAll writes separate method outputs and comparisons. Reject input aliases
// before any write so a loaded background cannot accidentally be overwritten.
func (r Results) SaveAll(out, source string) error {
	if out == "" {
		return errors.New("не выбран каталог результатов")
	}
	items := map[string]*image.RGBA{"overlay.png": r.Overlay, "difference.png": r.Difference, "zoom.png": r.Zoom}
	for i, name := range Names {
		items[name+".png"] = r.Images[i]
	}
	for name, img := range items {
		if img == nil {
			return errors.New("сначала выполните построение")
		}
		if err := protect(source, filepath.Join(out, name)); err != nil {
			return err
		}
	}
	if err := protect(source, filepath.Join(out, "metrics.json")); err != nil {
		return err
	}
	if err := os.MkdirAll(out, 0755); err != nil {
		return err
	}
	for name, img := range items {
		if err := Save(filepath.Join(out, name), img); err != nil {
			return err
		}
	}
	data, err := json.MarshalIndent(r.Metrics, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(out, "metrics.json"), append(data, '\n'), 0644)
}
func protect(source, target string) error {
	if source == "" {
		return nil
	}
	a, _ := filepath.Abs(source)
	b, _ := filepath.Abs(target)
	if a == b {
		return errors.New("выходной файл совпадает с фоном; выберите другой каталог")
	}
	sa, ea := os.Stat(source)
	sb, eb := os.Stat(target)
	if ea == nil && eb == nil && os.SameFile(sa, sb) {
		return errors.New("выходной файл ссылается на фон; выберите другой каталог")
	}
	return nil
}
```

## Листинг 3.7 — internal/native/native.go

```go
// Package native uses the real X11 circle primitive as the fourth method.
// No private approximation is substituted for a server-rendered arc.
package native

import (
	"errors"
	"fmt"
	"github.com/jezek/xgb"
	"github.com/jezek/xgb/xproto"
	"graphiclabs/lb4/internal/raster"
	"math"
)

func Rasterize(cfg raster.Config) (*raster.Mask, error) {
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	c, err := xgb.NewConn()
	if err != nil {
		return nil, fmt.Errorf("четвёртому методу нужен X11/XWayland и DISPLAY: %w", err)
	}
	defer c.Close()
	setup := xproto.Setup(c)
	screen := setup.DefaultScreen(c)
	valid := false
	for _, d := range screen.AllowedDepths {
		for _, v := range d.Visuals {
			if v.VisualId == screen.RootVisual && v.RedMask == 0xff0000 && v.GreenMask == 0xff00 && v.BlueMask == 0xff {
				valid = true
			}
		}
	}
	bpp := byte(0)
	for _, f := range setup.PixmapFormats {
		if f.Depth == screen.RootDepth {
			bpp = f.BitsPerPixel
		}
	}
	if !valid || bpp != 32 || setup.ImageByteOrder != xproto.ImageOrderLSBFirst {
		return nil, errors.New("требуется X11 TrueColor с 32-битным хранением LSBFirst")
	}
	pix, err := xproto.NewPixmapId(c)
	if err != nil {
		return nil, err
	}
	if err = xproto.CreatePixmapChecked(c, screen.RootDepth, pix, xproto.Drawable(screen.Root), uint16(cfg.Width), uint16(cfg.Height)).Check(); err != nil {
		return nil, err
	}
	defer xproto.FreePixmap(c, pix)
	gc, err := xproto.NewGcontextId(c)
	if err != nil {
		return nil, err
	}
	if err = xproto.CreateGCChecked(c, gc, xproto.Drawable(pix), xproto.GcForeground|xproto.GcLineWidth, []uint32{0, 0}).Check(); err != nil {
		return nil, err
	}
	defer xproto.FreeGC(c, gc)
	if err = xproto.PolyFillRectangleChecked(c, xproto.Drawable(pix), gc, []xproto.Rectangle{{Width: uint16(cfg.Width), Height: uint16(cfg.Height)}}).Check(); err != nil {
		return nil, err
	}
	if err = xproto.ChangeGCChecked(c, gc, xproto.GcForeground, []uint32{0xffffff}).Check(); err != nil {
		return nil, err
	}
	var arcs []xproto.Arc
	var ends []xproto.Point
	for _, a := range cfg.Arcs() {
		// X11 angles are counter-clockwise, while our screen angles increase clockwise.
		arcs = append(arcs, xproto.Arc{X: int16(math.Round(a.Center.X)) - int16(a.Radius), Y: int16(math.Round(a.Center.Y)) - int16(a.Radius), Width: uint16(2 * a.Radius), Height: uint16(2 * a.Radius), Angle1: int16(-a.Start * 64), Angle2: int16(-a.Sweep * 64)})
		if a.Sweep < 360 {
			for _, t := range []float64{a.Start, a.Start + a.Sweep} {
				p := a.At(t)
				ends = append(ends, xproto.Point{X: int16(math.Round(p.X)), Y: int16(math.Round(p.Y))})
			}
		}
	}
	if err = xproto.PolyArcChecked(c, xproto.Drawable(pix), gc, arcs).Check(); err != nil {
		return nil, err
	}
	// Explicit shared endpoints use the same rounded vertices as the custom methods.
	if len(ends) > 0 {
		if err = xproto.PolyPointChecked(c, xproto.CoordModeOrigin, xproto.Drawable(pix), gc, ends).Check(); err != nil {
			return nil, err
		}
	}
	reply, err := xproto.GetImage(c, xproto.ImageFormatZPixmap, xproto.Drawable(pix), 0, 0, uint16(cfg.Width), uint16(cfg.Height), 0xffffffff).Reply()
	if err != nil {
		return nil, err
	}
	if len(reply.Data) != cfg.Width*cfg.Height*4 {
		return nil, errors.New("неожиданный формат растра X11")
	}
	m := raster.NewMask(cfg.Width, cfg.Height)
	for i := range m.Bits {
		k := 4 * i
		m.Bits[i] = reply.Data[k] != 0 || reply.Data[k+1] != 0 || reply.Data[k+2] != 0
	}
	return m, nil
}
```

## Листинг 3.8 — internal/desktop/process.go

```go
package desktop

import (
	"graphiclabs/lb4/internal/native"
	"graphiclabs/lb4/internal/raster"
	"image"
)

func Process(background *image.RGBA, c raster.Config) (raster.Results, error) {
	masks, err := raster.Custom(c)
	if err != nil {
		return raster.Results{}, err
	}
	builtin, err := native.Rasterize(c)
	if err != nil {
		return raster.Results{}, err
	}
	return raster.Compose(background, c, [4]*raster.Mask{masks[0], masks[1], masks[2], builtin})
}
```

## Листинг 3.9 — internal/desktop/window.go

```go
// Package desktop is a native X11 client written in Go, without CGO.
package desktop

import (
	_ "embed"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"os"

	"github.com/jezek/xgb"
	"github.com/jezek/xgb/xproto"
	xdraw "golang.org/x/image/draw"
	"golang.org/x/image/font"
	"golang.org/x/image/font/opentype"
	"golang.org/x/image/math/fixed"

	"graphiclabs/lb4/internal/raster"
)

//go:embed assets/DejaVuSans.ttf
var fontData []byte

const frameW, frameH = 1200, 840

type button struct {
	rect          image.Rectangle
	label, action string
}
type app struct {
	conn                                          *xgb.Conn
	win                                           xproto.Window
	gc                                            xproto.Gcontext
	screen                                        *xproto.ScreenInfo
	wmDelete                                      xproto.Atom
	keys                                          *xproto.GetKeyboardMappingReply
	minKey                                        xproto.Keycode
	width, height                                 int
	faces                                         map[int]font.Face
	buttons                                       []button
	source                                        *image.RGBA
	results                                       raster.Results
	sourcePath, out, size, cx, cy, radius, status string
	config                                        raster.Config
	view                                          int
	focus                                         int
	selectAll                                     bool
	dialog, dir, dirInput                         string
	entries                                       []os.DirEntry
	page                                          int
}

func Run(src *image.RGBA, sourcePath, out string, cfg raster.Config) error {
	c, err := xgb.NewConn()
	if err != nil {
		return fmt.Errorf("не удалось открыть окно X11: %w; требуется графический сеанс X11/XWayland", err)
	}
	defer c.Close()
	setup := xproto.Setup(c)
	screen := setup.DefaultScreen(c)
	valid := false
	for _, depth := range screen.AllowedDepths {
		for _, v := range depth.Visuals {
			if v.VisualId == screen.RootVisual && v.RedMask == 0xff0000 && v.GreenMask == 0xff00 && v.BlueMask == 0xff {
				valid = true
			}
		}
	}
	bpp := byte(0)
	for _, f := range setup.PixmapFormats {
		if f.Depth == screen.RootDepth {
			bpp = f.BitsPerPixel
		}
	}
	if !valid || bpp != 32 || setup.ImageByteOrder != xproto.ImageOrderLSBFirst {
		return errors.New("нужен X11 TrueColor с 32-битными пикселями LSBFirst (обычный Linux desktop)")
	}
	win, err := xproto.NewWindowId(c)
	if err != nil {
		return err
	}
	gc, err := xproto.NewGcontextId(c)
	if err != nil {
		return err
	}
	a := &app{conn: c, win: win, gc: gc, screen: screen, source: src, sourcePath: sourcePath,
		out: out, size: fmt.Sprint(cfg.Size), cx: fmt.Sprint(cfg.CX), cy: fmt.Sprint(cfg.CY), radius: fmt.Sprint(cfg.Radius), config: cfg, faces: map[int]font.Face{},
		status: "Задайте ширину и положение. Нажмите «Построить». Вариант 28 % 20 = 8.", focus: 1,
		width: min(frameW, int(screen.WidthInPixels)-40), height: min(frameH, int(screen.HeightInPixels)-80)}
	if a.width < 480 || a.height < 400 {
		return errors.New("для окна требуется экран не менее 520×480")
	}
	fontFile, err := opentype.Parse(fontData)
	if err != nil {
		return err
	}
	for _, size := range []int{14, 16, 18, 26} {
		face, e := opentype.NewFace(fontFile, &opentype.FaceOptions{Size: float64(size), DPI: 72, Hinting: font.HintingFull})
		if e != nil {
			return e
		}
		a.faces[size] = face
		defer face.Close()
	}
	a.minKey = setup.MinKeycode
	a.keys, err = xproto.GetKeyboardMapping(c, setup.MinKeycode, byte(int(setup.MaxKeycode)-int(setup.MinKeycode)+1)).Reply()
	if err != nil {
		return err
	}
	mask := uint32(xproto.EventMaskExposure | xproto.EventMaskButtonPress | xproto.EventMaskKeyPress | xproto.EventMaskStructureNotify)
	err = xproto.CreateWindowChecked(c, screen.RootDepth, win, screen.Root, 0, 0, uint16(a.width), uint16(a.height), 0,
		xproto.WindowClassInputOutput, screen.RootVisual, xproto.CwBackPixel|xproto.CwEventMask, []uint32{screen.WhitePixel, mask}).Check()
	if err != nil {
		return err
	}
	defer xproto.DestroyWindow(c, win)
	if err = xproto.CreateGCChecked(c, gc, xproto.Drawable(win), 0, nil).Check(); err != nil {
		return err
	}
	defer xproto.FreeGC(c, gc)
	title := "Lab4 - Circle rasterization - Variant 8"
	xproto.ChangeProperty(c, xproto.PropModeReplace, win, xproto.AtomWmName, xproto.AtomString, 8, uint32(len(title)), []byte(title))
	protocols, e := xproto.InternAtom(c, false, 12, "WM_PROTOCOLS").Reply()
	if e != nil {
		return e
	}
	closeAtom, e := xproto.InternAtom(c, false, 16, "WM_DELETE_WINDOW").Reply()
	if e != nil {
		return e
	}
	a.wmDelete = closeAtom.Atom
	data := make([]byte, 4)
	xgb.Put32(data, uint32(closeAtom.Atom))
	xproto.ChangeProperty(c, xproto.PropModeReplace, win, protocols.Atom, xproto.AtomAtom, 32, 1, data)
	if err = xproto.MapWindowChecked(c, win).Check(); err != nil {
		return err
	}
	if err = a.paint(); err != nil {
		return err
	}
	for {
		event, e := c.WaitForEvent()
		if e != nil {
			return e
		}
		if event == nil {
			return nil
		}
		switch ev := event.(type) {
		case xproto.ClientMessageEvent:
			if ev.Data.Data32[0] == uint32(a.wmDelete) {
				return nil
			}
		case xproto.DestroyNotifyEvent:
			return nil
		case xproto.ConfigureNotifyEvent:
			a.width, a.height = int(ev.Width), int(ev.Height)
		case xproto.ExposeEvent:
			if ev.Count != 0 {
				continue
			}
		case xproto.ButtonPressEvent:
			x, y := a.toFrame(int(ev.EventX), int(ev.EventY))
			a.click(x, y, ev.Detail)
		case xproto.KeyPressEvent:
			a.key(ev)
		default:
			continue
		}
		if err = a.paint(); err != nil {
			return err
		}
	}
}

func (a *app) viewport() image.Rectangle {
	scale := min(float64(a.width)/frameW, float64(a.height)/frameH)
	w, h := int(frameW*scale), int(frameH*scale)
	x, y := (a.width-w)/2, (a.height-h)/2
	return image.Rect(x, y, x+w, y+h)
}
func (a *app) toFrame(x, y int) (int, int) {
	r := a.viewport()
	if r.Empty() {
		return -1, -1
	}
	return (x - r.Min.X) * frameW / r.Dx(), (y - r.Min.Y) * frameH / r.Dy()
}

func (a *app) paint() error {
	if a.width < 1 || a.height < 1 || a.width > 8192 || a.height > 8192 {
		return nil
	}
	canvas := a.render()
	view := image.NewRGBA(image.Rect(0, 0, a.width, a.height))
	draw.Draw(view, view.Bounds(), image.NewUniform(color.RGBA{231, 236, 243, 255}), image.Point{}, draw.Src)
	xdraw.ApproxBiLinear.Scale(view, a.viewport(), canvas, canvas.Bounds(), draw.Src, nil)
	// X11 PutImage uses B,G,R,pad. Chunk rows to stay below request size limits.
	rows := max(1, (int(xproto.Setup(a.conn).MaximumRequestLength)*4-64)/(a.width*4))
	for y := 0; y < a.height; y += rows {
		n := min(rows, a.height-y)
		buf := make([]byte, a.width*n*4)
		for j := 0; j < n; j++ {
			for x := 0; x < a.width; x++ {
				p := view.RGBAAt(x, y+j)
				k := (j*a.width + x) * 4
				buf[k], buf[k+1], buf[k+2] = p.B, p.G, p.R
			}
		}
		if err := xproto.PutImageChecked(a.conn, xproto.ImageFormatZPixmap, xproto.Drawable(a.win), a.gc,
			uint16(a.width), uint16(n), 0, int16(y), 0, a.screen.RootDepth, buf).Check(); err != nil {
			return err
		}
	}
	return nil
}

func fill(m *image.RGBA, r image.Rectangle, c color.RGBA) {
	draw.Draw(m, r, image.NewUniform(c), image.Point{}, draw.Src)
}
func (a *app) text(m *image.RGBA, x, y, size int, s string, c color.RGBA) {
	d := font.Drawer{Dst: m, Src: image.NewUniform(c), Face: a.faces[size], Dot: fixed.P(x, y)}
	d.DrawString(s)
}
```

## Листинг 3.10 — internal/desktop/ui.go

```go
package desktop

import (
	"errors"
	"fmt"
	"github.com/jezek/xgb/xproto"
	xdraw "golang.org/x/image/draw"
	"graphiclabs/lb4/internal/raster"
	"image"
	"image/color"
	"image/draw"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"
)

var ink = color.RGBA{36, 51, 73, 255}
var blue = color.RGBA{35, 91, 175, 255}
var muted = color.RGBA{87, 105, 129, 255}
var white = color.RGBA{255, 255, 255, 255}
var fields = map[int]image.Rectangle{1: image.Rect(100, 130, 180, 166), 4: image.Rect(270, 130, 350, 166), 5: image.Rect(440, 130, 520, 166), 6: image.Rect(620, 130, 700, 166), 2: image.Rect(142, 182, 952, 218)}

func (a *app) add(m *image.RGBA, r image.Rectangle, label, action string) {
	a.buttons = append(a.buttons, button{r, label, action})
	fill(m, r, blue)
	a.text(m, r.Min.X+12, r.Min.Y+25, 16, label, white)
}
func (a *app) field(m *image.RGBA, r image.Rectangle, text string, id int) {
	c := color.RGBA{186, 198, 214, 255}
	if a.focus == id {
		c = blue
	}
	fill(m, r, c)
	fill(m, r.Inset(2), white)
	limit := r.Dx()/10 - 2
	s := []rune(text)
	if len(s) > limit {
		s = s[len(s)-limit:]
	}
	a.text(m, r.Min.X+8, r.Min.Y+25, 16, string(s), ink)
}
func (a *app) render() *image.RGBA {
	m := image.NewRGBA(image.Rect(0, 0, frameW, frameH))
	a.buttons = nil
	fill(m, m.Bounds(), color.RGBA{240, 244, 249, 255})
	a.text(m, 24, 38, 26, "Растеризация окружностей", ink)
	a.text(m, 24, 64, 14, "Лабораторная 04 / Номер 28 / Вариант 08 — треугольник Рёло заданной ширины", muted)
	a.add(m, image.Rect(24, 80, 230, 116), "Открыть фон…", "open")
	a.add(m, image.Rect(242, 80, 380, 116), "Белый фон", "blank")
	shape := "Треугольник Рёло"
	if a.config.Circle {
		shape = "Окружность"
	}
	a.add(m, image.Rect(392, 80, 700, 116), "Фигура: "+shape, "shape")
	a.add(m, image.Rect(712, 80, 932, 116), "Построить 4 метода", "all")
	a.add(m, image.Rect(944, 80, 1176, 116), "Сохранить результаты", "save-all")
	for _, f := range []struct {
		id, x        int
		label, value string
	}{{1, 24, "Ширина", a.size}, {4, 200, "Центр X", a.cx}, {5, 370, "Центр Y", a.cy}, {6, 540, "R окруж.", a.radius}} {
		a.text(m, f.x, 154, 16, f.label, ink)
		a.field(m, fields[f.id], f.value, f.id)
	}
	views := []string{"Четыре метода", "Сравнение и фон", "Пиксели крупно"}
	a.add(m, image.Rect(740, 130, 1176, 166), "Вид: "+views[a.view], "view")
	a.text(m, 24, 206, 16, "Каталог PNG", ink)
	a.field(m, fields[2], a.out, 2)
	a.add(m, image.Rect(966, 182, 1176, 218), "Выбрать каталог…", "directory")
	for i, line := range wrap(a.status, 118) {
		if i == 2 {
			break
		}
		a.text(m, 24, 245+i*20, 14, line, muted)
	}
	imgs := a.results.Images
	labels := [4]string{"1. Уравнение окружности", "2. Параметрическое уравнение", "3. Алгоритм Брезенхема", "4. Примитив X11 PolyArc"}
	if a.view == 1 {
		imgs = [4]*image.RGBA{a.results.Overlay, a.results.Difference, a.results.Zoom, a.source}
		labels = [4]string{"Наложение: общие — чёрные", "Различия — красные; общие — серые", "Одинаковый участок, пиксели ×8", "Исходный фон"}
	}
	for i, src := range imgs {
		x, y := 24+(i%2)*584, 284+(i/2)*264
		fill(m, image.Rect(x, y, x+568, y+248), white)
		a.text(m, x+12, y+25, 16, labels[i], ink)
		r := image.Rect(x+12, y+46, x+556, y+236)
		fill(m, r, color.RGBA{231, 237, 245, 255})
		if src == nil {
			a.text(m, x+32, y+140, 16, "Нажмите «Построить 4 метода»", muted)
			continue
		}
		bounds := src.Bounds()
		if a.view == 2 {
			bounds = a.results.Metrics.Config.ZoomRect()
			crop, _ := raster.New(32, 32)
			draw.Draw(crop, crop.Bounds(), src, bounds.Min, draw.Src)
			src = crop
			bounds = src.Bounds()
		}
		scale := min(float64(r.Dx())/float64(bounds.Dx()), float64(r.Dy())/float64(bounds.Dy()))
		w, h := int(float64(bounds.Dx())*scale), int(float64(bounds.Dy())*scale)
		l, t := r.Min.X+(r.Dx()-w)/2, r.Min.Y+(r.Dy()-h)/2
		if scale < 1 {
			// Area-aware preview only; saved rasters retain the original pixels.
			xdraw.CatmullRom.Scale(m, image.Rect(l, t, l+w, t+h), src, bounds, draw.Src, nil)
		} else {
			xdraw.NearestNeighbor.Scale(m, image.Rect(l, t, l+w, t+h), src, bounds, draw.Src, nil)
		}
	}
	a.text(m, 24, 832, 14, "Рёло: ширина = радиус каждой из трёх дуг. R окруж. используется только в режиме окружности.", muted)
	if a.dialog != "" {
		a.renderDialog(m)
	}
	return m
}
func wrap(s string, n int) []string {
	var lines []string
	for _, w := range strings.Fields(s) {
		if len(lines) == 0 || len([]rune(lines[len(lines)-1]+" "+w)) > n {
			lines = append(lines, w)
		} else {
			lines[len(lines)-1] += " " + w
		}
	}
	return lines
}
func (a *app) click(x, y int, detail xproto.Button) {
	p := image.Pt(x, y)
	if a.dialog != "" && (detail == 4 || detail == 5) {
		if detail == 4 {
			a.page = max(0, a.page-1)
		} else {
			a.page = min(max(0, (len(a.entries)-1)/16), a.page+1)
		}
		return
	}
	if detail != 1 {
		return
	}
	if a.dialog != "" {
		if p.In(image.Rect(110, 140, 925, 176)) {
			a.focus = 3
			a.selectAll = true
			return
		}
	} else {
		for id, r := range fields {
			if p.In(r) {
				a.focus = id
				a.selectAll = true
				return
			}
		}
	}
	for _, b := range a.buttons {
		if p.In(b.rect) {
			if err := a.action(b.action); err != nil {
				a.status = "Ошибка: " + err.Error()
			}
			return
		}
	}
}
func (a *app) parameters() (raster.Config, error) {
	c := a.config
	for _, f := range []struct {
		s string
		p *int
	}{{a.size, &c.Size}, {a.cx, &c.CX}, {a.cy, &c.CY}, {a.radius, &c.Radius}} {
		n, err := strconv.Atoi(strings.TrimSpace(f.s))
		if err != nil {
			return c, errors.New("ширина, координаты и радиус должны быть целыми числами")
		}
		*f.p = n
	}
	c.Width, c.Height = a.source.Rect.Dx(), a.source.Rect.Dy()
	return c, c.Validate()
}
func (a *app) action(action string) error {
	switch action {
	case "open", "directory":
		a.dialog = action
		a.page = 0
		a.focus = 3
		dir, err := os.Getwd()
		if err != nil {
			return err
		}
		if action == "directory" && a.out != "" {
			dir = a.out
		}
		if action == "open" && a.sourcePath != "" {
			dir = filepath.Dir(a.sourcePath)
		}
		if err = a.readDir(dir); err != nil {
			fallback, _ := os.Getwd()
			return a.readDir(fallback)
		}
	case "close":
		a.dialog = ""
		a.focus = 1
	case "browse":
		return a.readDir(a.dirInput)
	case "parent":
		return a.readDir(filepath.Dir(a.dir))
	case "prev":
		a.page = max(0, a.page-1)
	case "next":
		a.page = min(max(0, (len(a.entries)-1)/16), a.page+1)
	case "choose-dir":
		a.out = a.dir
		a.dialog = ""
		a.focus = 2
	case "blank":
		a.source, _ = raster.New(640, 480)
		a.sourcePath = ""
		a.results = raster.Results{}
		a.status = "Белый холст 640×480. Нажмите «Построить»."
	case "shape":
		a.config.Circle = !a.config.Circle
		a.results = raster.Results{}
		a.status = "Фигура изменена. Нажмите «Построить»."
	case "view":
		a.view = (a.view + 1) % 3
	case "all":
		c, err := a.parameters()
		if err != nil {
			return err
		}
		r, err := Process(a.source, c)
		if err != nil {
			return err
		}
		a.results = r
		a.config = c
		a.status = fmt.Sprintf("Пикселей: %v. Общих: %d. Различающихся в объединении: %d. Параметры применены.", r.Metrics.Pixels, r.Metrics.Common, r.Metrics.Different)
	case "save-all":
		if err := a.results.SaveAll(a.out, a.sourcePath); err != nil {
			return err
		}
		a.status = "Сохранены 7 PNG и metrics.json: " + a.out
	default:
		if !strings.HasPrefix(action, "entry-") {
			return errors.New("неизвестное действие")
		}
		i, err := strconv.Atoi(strings.TrimPrefix(action, "entry-"))
		if err != nil || i < 0 || i >= len(a.entries) {
			return errors.New("неверный файл")
		}
		path := filepath.Join(a.dir, a.entries[i].Name())
		if a.entries[i].IsDir() {
			return a.readDir(path)
		}
		img, err := raster.Load(path)
		if err != nil {
			return err
		}
		a.source = img
		a.sourcePath = path
		a.results = raster.Results{}
		a.dialog = ""
		a.focus = 1
		a.status = fmt.Sprintf("Загружен фон %s, %d×%d. Проверьте положение фигуры и нажмите «Построить».", filepath.Base(path), img.Rect.Dx(), img.Rect.Dy())
	}
	return nil
}

func (a *app) readDir(path string) error {
	full, err := filepath.Abs(path)
	if err != nil {
		return err
	}
	entries, err := os.ReadDir(full)
	if err != nil {
		return err
	}
	var list []os.DirEntry
	for _, e := range entries {
		ext := strings.ToLower(filepath.Ext(e.Name()))
		if e.IsDir() || a.dialog == "open" && (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".gif") {
			list = append(list, e)
		}
	}
	sort.SliceStable(list, func(i, j int) bool {
		if list[i].IsDir() != list[j].IsDir() {
			return list[i].IsDir()
		}
		return list[i].Name() < list[j].Name()
	})
	a.dir, a.dirInput, a.entries, a.page = full, full, list, 0
	return nil
}

func (a *app) renderDialog(m *image.RGBA) {
	a.buttons = nil
	fill(m, image.Rect(88, 80, 1112, 790), color.RGBA{211, 220, 233, 255})
	fill(m, image.Rect(92, 84, 1108, 786), white)
	title := "Открыть изображение — PNG / JPEG / GIF"
	if a.dialog == "directory" {
		title = "Выбрать каталог сохранения"
	}
	a.text(m, 110, 118, 18, title, ink)
	a.field(m, image.Rect(110, 140, 925, 176), a.dirInput, 3)
	a.add(m, image.Rect(940, 140, 1088, 176), "Перейти", "browse")
	a.add(m, image.Rect(110, 190, 260, 226), "На уровень выше", "parent")
	a.add(m, image.Rect(938, 190, 1088, 226), "Отмена", "close")
	for row := 0; row < 16; row++ {
		i := a.page*16 + row
		if i >= len(a.entries) {
			break
		}
		e := a.entries[i]
		y := 240 + row*28
		r := image.Rect(110, y, 1088, y+27)
		if row%2 == 0 {
			fill(m, r, color.RGBA{238, 242, 248, 255})
		}
		label := e.Name()
		if e.IsDir() {
			label = "[каталог]  " + label
		}
		if len([]rune(label)) > 95 {
			label = string([]rune(label)[:92]) + "…"
		}
		a.text(m, 122, y+20, 16, label, ink)
		a.buttons = append(a.buttons, button{r, label, fmt.Sprint("entry-", i)})
	}
	a.add(m, image.Rect(110, 708, 240, 744), "Предыдущие", "prev")
	a.add(m, image.Rect(252, 708, 382, 744), "Следующие", "next")
	if a.dialog == "directory" {
		a.add(m, image.Rect(790, 708, 1088, 744), "Выбрать этот каталог", "choose-dir")
	}
	message := "Клик по каталогу открывает его; клик по файлу загружает изображение. Esc — отмена."
	if strings.HasPrefix(a.status, "Ошибка:") {
		lines := wrap(a.status, 120)
		if len(lines) > 0 {
			message = lines[0]
		}
	}
	a.text(m, 110, 770, 14, message, muted)
}

func (a *app) key(e xproto.KeyPressEvent) {
	index := (int(e.Detail) - int(a.minKey)) * int(a.keys.KeysymsPerKeycode)
	if index < 0 || index >= len(a.keys.Keysyms) {
		return
	}
	if e.State&xproto.ModMaskShift != 0 && a.keys.KeysymsPerKeycode > 1 {
		index++
	}
	sym := uint32(a.keys.Keysyms[index])
	if sym == 0xff1b {
		a.dialog = ""
		a.focus = 1
		return
	}
	if sym == 0xff09 {
		if a.dialog != "" {
			a.focus = 3
		} else {
			a.focus = a.focus%6 + 1
			if a.focus == 3 {
				a.focus = 4
			}
		}
		a.selectAll = true
		return
	}
	if e.State&xproto.ModMaskControl != 0 {
		if sym == 'a' || sym == 'A' {
			a.selectAll = true
		}
		return
	}
	var field *string
	switch a.focus {
	case 1:
		field = &a.size
	case 2:
		field = &a.out
	case 3:
		field = &a.dirInput
	case 4:
		field = &a.cx
	case 5:
		field = &a.cy
	case 6:
		field = &a.radius
	default:
		return
	}
	if sym == 0xff0d {
		action := "all"
		if a.dialog != "" {
			action = "browse"
		}
		if err := a.action(action); err != nil {
			a.status = "Ошибка: " + err.Error()
		}
		return
	}
	if sym == 0xff08 || sym == 0xffff {
		if a.selectAll {
			*field = ""
		} else if len(*field) > 0 {
			_, size := utf8.DecodeLastRuneInString(*field)
			*field = (*field)[:len(*field)-size]
		}
		a.selectAll = false
		return
	}
	ch := rune(0)
	if sym >= 32 && sym < 127 || sym >= 160 && sym <= 255 {
		ch = rune(sym)
	}
	if sym&0xff000000 == 0x01000000 {
		ch = rune(sym & 0xffffff)
	}
	if ch == 0 || len([]rune(*field)) >= 1000 {
		return
	}
	if a.selectAll {
		*field = ""
		a.selectAll = false
	}
	*field += string(ch)
}
```

## Листинг 3.11 — cmd/lab4/main_test.go

```go
package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestCLIValidation(t *testing.T) {
	for _, args := range [][]string{{"-mode", "bad"}, {"-shape", "oval"}, {"-size", "0"}, {"-source", "/does-not-exist.png"}, {"unexpected"}} {
		if err := run(args); err == nil {
			t.Fatalf("invalid accepted %v", args)
		}
	}
	if err := run([]string{"-h"}); err != nil {
		t.Fatal(err)
	}
}
func TestBatch(t *testing.T) {
	if os.Getenv("DISPLAY") == "" {
		t.Skip("fourth method requires X11")
	}
	dir := t.TempDir()
	if err := run([]string{"-mode", "batch", "-out", dir, "-size", "80", "-cx", "60", "-cy", "60", "-width", "120", "-height", "120"}); err != nil {
		t.Fatal(err)
	}
	for _, n := range []string{"equation.png", "parametric.png", "bresenham.png", "native.png", "overlay.png", "difference.png", "zoom.png", "metrics.json"} {
		if _, err := os.Stat(filepath.Join(dir, n)); err != nil {
			t.Fatal(err)
		}
	}
}
```

## Листинг 3.12 — internal/raster/circle_test.go

```go
package raster

import (
	"bytes"
	"image"
	"image/color"
	"math"
	"os"
	"path/filepath"
	"testing"
)

func connected(m *Mask) bool {
	start := -1
	for i, v := range m.Bits {
		if v {
			start = i
			break
		}
	}
	if start < 0 {
		return false
	}
	seen := map[int]bool{start: true}
	q := []int{start}
	for len(q) > 0 {
		n := q[0]
		q = q[1:]
		x, y := n%m.W, n/m.W
		for dy := -1; dy <= 1; dy++ {
			for dx := -1; dx <= 1; dx++ {
				xx, yy := x+dx, y+dy
				k := yy*m.W + xx
				if m.At(xx, yy) && !seen[k] {
					seen[k] = true
					q = append(q, k)
				}
			}
		}
	}
	return len(seen) == m.Count()
}
func TestReuleauxGeometry(t *testing.T) {
	c := Default()
	v := c.Vertices()
	for i := 0; i < 3; i++ {
		a, b := v[i], v[(i+1)%3]
		if math.Abs(math.Hypot(a.X-b.X, a.Y-b.Y)-float64(c.Size)) > 1e-9 {
			t.Fatal("side length")
		}
	}
	// Independent support-width check over dense continuous arc samples.
	var points []Point
	for _, a := range c.Arcs() {
		for k := 0; k <= 4096; k++ {
			points = append(points, a.At(a.Start+a.Sweep*float64(k)/4096))
		}
	}
	for degree := 0; degree < 180; degree++ {
		ux, uy := math.Cos(float64(degree)*math.Pi/180), math.Sin(float64(degree)*math.Pi/180)
		lo, hi := math.Inf(1), math.Inf(-1)
		for _, p := range points {
			s := p.X*ux + p.Y*uy
			lo = math.Min(lo, s)
			hi = math.Max(hi, s)
		}
		if math.Abs(hi-lo-float64(c.Size)) > .001 {
			t.Fatalf("width at %d: %.8f", degree, hi-lo)
		}
	}
}
func TestCircleAccuracySymmetryAndConnectivity(t *testing.T) {
	for _, radius := range []int{1, 2, 3, 7, 25, 100, 280} {
		c := Config{640, 640, 320, 320, 280, radius, true}
		ms, err := Custom(c)
		if err != nil {
			t.Fatal(err)
		}
		for method, m := range ms {
			if !connected(m) {
				t.Fatalf("disconnected radius=%d method=%d", radius, method)
			}
			for _, p := range []image.Point{{320 + radius, 320}, {320 - radius, 320}, {320, 320 + radius}, {320, 320 - radius}} {
				if !m.At(p.X, p.Y) {
					t.Fatal("missing cardinal")
				}
			}
			for n, on := range m.Bits {
				if !on {
					continue
				}
				x, y := n%m.W-320, n/m.W-320
				if math.Abs(math.Hypot(float64(x), float64(y))-float64(radius)) > 1 {
					t.Fatalf("radial error %d %d", radius, method)
				}
				// The angular stepping method is allowed different tie-breaking.
				if method != 1 && (!m.At(320-x, 320+y) || !m.At(320+y, 320+x)) {
					t.Fatal("broken eightfold symmetry")
				}
			}
		}
	}
}
func TestReuleauxContoursAndTranslation(t *testing.T) {
	for _, size := range []int{1, 2, 3, 7, 31, 80, 279, 280} {
		c := Default()
		c.Size = size
		ms, err := Custom(c)
		if err != nil {
			t.Fatal(err)
		}
		c2 := c
		c2.CX += 7
		c2.CY -= 5
		shift, _ := Custom(c2)
		for method, m := range ms {
			if !connected(m) {
				t.Fatalf("disconnected size=%d method=%d", size, method)
			}
			for _, p := range c.Vertices() {
				if !m.At(int(math.Round(p.X)), int(math.Round(p.Y))) {
					t.Fatal("missing shared vertex")
				}
			}
			for i, on := range m.Bits {
				if !on {
					continue
				}
				x, y := i%m.W, i/m.W
				if !shift[method].At(x+7, y-5) {
					t.Fatal("translation changed shape")
				}
				closest := math.Inf(1)
				for _, a := range c.Arcs() {
					e := math.Hypot(float64(x)-a.Center.X, float64(y)-a.Center.Y) - float64(size)
					closest = math.Min(closest, math.Abs(e))
					if e > 1.5 {
						t.Fatal("outside disk intersection", size, method)
					}
				}
				if closest > 1.2 {
					t.Fatal("not near boundary", size, method, closest)
				}
			}
		}
	}
}
func TestBresenhamDecisionAndClipping(t *testing.T) {
	for _, r := range []int{1, 2, 13, 280, 2048} {
		steps := Trace(r)
		for i, s := range steps {
			// d = 2*F(x+1,y-1/2)+1/2, evaluated using integer arithmetic.
			expected := 2*(s.X+1)*(s.X+1) + 2*s.Y*s.Y - 2*s.Y + 1 - 2*r*r
			if s.D != expected {
				t.Fatalf("decision invariant: %+v want %d", s, expected)
			}
			if i > 0 && (s.X != steps[i-1].X+1 || s.Y > steps[i-1].Y || s.Y < steps[i-1].Y-1) {
				t.Fatal("invalid step")
			}
		}
	}
	c := Default()
	c.CX = 0
	c.CY = 0
	ms, _ := Custom(c)
	for _, m := range ms {
		if m.Clipped == 0 || m.Count() == 0 {
			t.Fatal("clipping")
		}
	}
	c.CX = -4096
	c.CY = -4096
	ms, _ = Custom(c)
	for _, m := range ms {
		if m.Count() != 0 {
			t.Fatal("offscreen")
		}
	}
}
func TestResultsIOAndInvalidInputs(t *testing.T) {
	c := Default()
	c.Width = 80
	c.Height = 70
	c.CX = 40
	c.CY = 35
	c.Size = 40
	bg, _ := New(80, 70)
	bg.SetRGBA(0, 0, color.RGBA{10, 20, 30, 255})
	before := append([]byte(nil), bg.Pix...)
	m, _ := Custom(c)
	r, err := Compose(bg, c, [4]*Mask{m[0], m[1], m[2], m[0]})
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(before, bg.Pix) || r.Images[0].RGBAAt(0, 0) != bg.RGBAAt(0, 0) {
		t.Fatal("background changed")
	}
	if r.Metrics.PairwiseXOR[0][3] != 0 || r.Metrics.Common+r.Metrics.Different != r.Metrics.Union {
		t.Fatal("comparison")
	}
	dir := t.TempDir()
	if err = r.SaveAll(dir, ""); err != nil {
		t.Fatal(err)
	}
	img, err := Load(filepath.Join(dir, "equation.png"))
	if err != nil || !bytes.Equal(img.Pix, r.Images[0].Pix) {
		t.Fatal("PNG roundtrip", err)
	}
	if err = r.SaveAll(dir, filepath.Join(dir, "equation.png")); err == nil {
		t.Fatal("overwrote input")
	}
	if err = os.WriteFile(filepath.Join(dir, "bad.png"), []byte("bad"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err = Load(filepath.Join(dir, "bad.png")); err == nil {
		t.Fatal("bad input accepted")
	}
	for _, bad := range []Config{{0, 10, 0, 0, 10, 10, false}, {10, 10, 0, 0, 0, 10, false}, {10, 10, 0, 0, 10, 0, false}, {10, 10, 99999, 0, 10, 10, false}} {
		if _, err = Custom(bad); err == nil {
			t.Fatal("invalid accepted")
		}
	}
}
```

## Листинг 3.13 — internal/native/native_test.go

```go
package native

import (
	"graphiclabs/lb4/internal/raster"
	"math"
	"os"
	"testing"
)

func TestRealX11CircleAndReuleaux(t *testing.T) {
	if os.Getenv("DISPLAY") == "" {
		t.Skip("requires X11/Xvfb")
	}
	for _, circle := range []bool{true, false} {
		c := raster.Default()
		c.Circle = circle
		m, err := Rasterize(c)
		if err != nil {
			t.Fatal(err)
		}
		if m.Count() < 100 {
			t.Fatal("empty native contour")
		}
		for i, on := range m.Bits {
			if !on {
				continue
			}
			x, y := float64(i%m.W), float64(i/m.W)
			nearest := math.Inf(1)
			for _, a := range c.Arcs() {
				distance := math.Hypot(x-a.Center.X, y-a.Center.Y) - float64(a.Radius)
				nearest = math.Min(nearest, math.Abs(distance))
				if !circle && distance > 1.5 {
					t.Fatal("wrong native arc orientation")
				}
			}
			if nearest > 1.5 {
				t.Fatal("native radial error", nearest)
			}
		}
	}
}
```

## Листинг 3.14 — internal/desktop/desktop_test.go

```go
package desktop

import (
	"bytes"
	"image"
	"image/png"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/jezek/xgb"
	"github.com/jezek/xgb/xproto"
	"graphiclabs/lb4/internal/raster"
)

// This is an actual X11 window test, not a painted mock-up.
func TestNativeWindowWorkflow(t *testing.T) {
	if os.Getenv("DISPLAY") == "" {
		t.Skip("requires X11/Xvfb; run with DISPLAY for native integration")
	}
	dir := t.TempDir()
	input := filepath.Join(dir, "source.png")
	out := filepath.Join(dir, "output")
	src, _ := raster.New(640, 480)
	if err := raster.Save(input, src); err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	if binary := os.Getenv("LAB4_GUI_BINARY"); binary != "" {
		cmd := exec.Command(binary, "-source", input, "-out", out, "-size", "180")
		cmd.Env = []string{"PATH=/nonexistent", "DISPLAY=" + os.Getenv("DISPLAY")}
		cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
		go func() { done <- cmd.Run() }()
	} else {
		go func() { done <- Run(src, input, out, raster.Default()) }()
	}
	c, err := xgb.NewConn()
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	screen := xproto.Setup(c).DefaultScreen(c)
	var win xproto.Window
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) && win == 0 {
		tree, err := xproto.QueryTree(c, screen.Root).Reply()
		if err != nil {
			t.Fatal(err)
		}
		for _, w := range tree.Children {
			p, e := xproto.GetProperty(c, false, w, xproto.AtomWmName, xproto.AtomString, 0, 100).Reply()
			if e == nil && strings.HasPrefix(string(p.Value), "Lab4 -") {
				win = w
				break
			}
		}
		if win == 0 {
			select {
			case err := <-done:
				t.Fatal("window failed", err)
			default:
			}
			time.Sleep(20 * time.Millisecond)
		}
	}
	if win == 0 {
		t.Fatal("window did not appear")
	}
	defer func() {
		atom, _ := xproto.InternAtom(c, false, 16, "WM_DELETE_WINDOW").Reply()
		data := xproto.ClientMessageDataUnionData32New([]uint32{uint32(atom.Atom), 0, 0, 0, 0})
		e := xproto.ClientMessageEvent{Format: 32, Window: win, Data: data}
		xproto.SendEvent(c, false, win, 0, string(e.Bytes()))
		select {
		case err := <-done:
			if err != nil {
				t.Error(err)
			}
		case <-time.After(5 * time.Second):
			t.Error("window did not close")
		}
	}()
	click := func(x, y int) {
		geom, e := xproto.GetGeometry(c, xproto.Drawable(win)).Reply()
		if e != nil {
			t.Fatal(e)
		}
		scale := min(float64(geom.Width)/frameW, float64(geom.Height)/frameH)
		px := int((float64(geom.Width)-frameW*scale)/2 + float64(x)*scale)
		py := int((float64(geom.Height)-frameH*scale)/2 + float64(y)*scale)
		ev := xproto.ButtonPressEvent{Detail: 1, Root: screen.Root, Event: win, EventX: int16(px), EventY: int16(py), SameScreen: true}
		if err := xproto.SendEventChecked(c, false, win, xproto.EventMaskButtonPress, string(ev.Bytes())).Check(); err != nil {
			t.Fatal(err)
		}
	}
	click(100, 98)  // Actual file chooser.
	click(300, 253) // First entry is the saved source.png.
	// Exercise the real width field: replace the release binary's initial 180 with 280.
	click(140, 148)
	setup := xproto.Setup(c)
	keys, e := xproto.GetKeyboardMapping(c, setup.MinKeycode, byte(int(setup.MaxKeycode)-int(setup.MinKeycode)+1)).Reply()
	if e != nil {
		t.Fatal(e)
	}
	for _, ch := range "280" {
		found := false
		for k := int(setup.MinKeycode); k <= int(setup.MaxKeycode); k++ {
			idx := (k - int(setup.MinKeycode)) * int(keys.KeysymsPerKeycode)
			if keys.Keysyms[idx] != xproto.Keysym(ch) {
				continue
			}
			ev := xproto.KeyPressEvent{Detail: xproto.Keycode(k), Root: screen.Root, Event: win, SameScreen: true}
			if err := xproto.SendEventChecked(c, false, win, xproto.EventMaskKeyPress, string(ev.Bytes())).Check(); err != nil {
				t.Fatal(err)
			}
			found = true
			break
		}
		if !found {
			t.Fatal("keyboard digit missing", ch)
		}
	}
	click(815, 98)  // All four methods.
	click(1030, 98) // Save all.
	deadline = time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		if _, err := os.Stat(filepath.Join(out, "native.png")); err == nil {
			break
		}
		time.Sleep(25 * time.Millisecond)
	}
	want, err := Process(src, raster.Default())
	if err != nil {
		t.Fatal(err)
	}
	for i, name := range []string{"equation.png", "parametric.png", "bresenham.png", "native.png"} {
		got, err := raster.Load(filepath.Join(out, name))
		if err != nil {
			t.Fatal("UI did not save", err)
		}
		expected := want.Images[i]
		if !bytes.Equal(got.Pix, expected.Pix) {
			t.Fatal("native result differs", name)
		}
	}
	for shot, path := range []string{os.Getenv("LAB4_GUI_CAPTURE"), os.Getenv("LAB4_GUI_COMPARISON")} {
		if path == "" {
			continue
		}
		if shot == 1 {
			click(900, 148)
		}
		// Let the final completed paint reach the X server, then read its window pixels.
		time.Sleep(250 * time.Millisecond)
		geom, err := xproto.GetGeometry(c, xproto.Drawable(win)).Reply()
		if err != nil {
			t.Fatal(err)
		}
		pixels, err := xproto.GetImage(c, xproto.ImageFormatZPixmap, xproto.Drawable(win), 0, 0, geom.Width, geom.Height, 0xffffffff).Reply()
		if err != nil {
			t.Fatal(err)
		}
		img := image.NewRGBA(image.Rect(0, 0, int(geom.Width), int(geom.Height)))
		for i := 0; i < len(img.Pix); i += 4 {
			img.Pix[i], img.Pix[i+1], img.Pix[i+2], img.Pix[i+3] = pixels.Data[i+2], pixels.Data[i+1], pixels.Data[i], 255
		}
		f, err := os.Create(path)
		if err != nil {
			t.Fatal(err)
		}
		err = png.Encode(f, img)
		closeErr := f.Close()
		if err != nil || closeErr != nil {
			t.Fatal(err, closeErr)
		}
	}
}

func TestInvalidParametersAndSaveOrder(t *testing.T) {
	src, _ := raster.New(640, 480)
	a := &app{source: src, config: raster.Default(), size: "bad", cx: "320", cy: "240", radius: "140", out: t.TempDir()}
	if err := a.action("all"); err == nil {
		t.Fatal("invalid width accepted")
	}
	if err := a.action("save-all"); err == nil {
		t.Fatal("saved before rendering")
	}
	a.size = "280"
	c, err := a.parameters()
	if err != nil || c != raster.Default() {
		t.Fatal("parameters", err)
	}
	if err = a.action("shape"); err != nil || !a.config.Circle {
		t.Fatal("shape toggle")
	}
}
```

# 4 Пример работы программы

Демонстрация выполнена готовым статическим бинарником Linux amd64. Холст — 640×480 пикселей, белый фон, положение центра (320;240), ширина треугольника Рёло 280 пикселей. Все изображения в разделе получены приложением; параметры и измеренные результаты сохранены в images/metrics.json. Отдельно проверены чтение PNG через файловый диалог и запись файлов из настоящего окна.

Рисунок 6 — Треугольник Рёло по уравнению окружности

![Рисунок 6 — Треугольник Рёло по уравнению окружности](../images/equation.png)

Рисунок 7 — Треугольник Рёло по параметрическому уравнению

![Рисунок 7 — Треугольник Рёло по параметрическому уравнению](../images/parametric.png)

Рисунок 8 — Треугольник Рёло по алгоритму Брезенхема

![Рисунок 8 — Треугольник Рёло по алгоритму Брезенхема](../images/bresenham.png)

Рисунок 9 — Треугольник Рёло примитивом X11 PolyArc

![Рисунок 9 — Треугольник Рёло примитивом X11 PolyArc](../images/native.png)

## 4.1 Измеренное сравнение

Число пикселей означает число уникальных позиций маски, а не число вызовов записи. Порядок методов во всех таблицах и увеличенных фрагментах: уравнение, параметрическое уравнение, Брезенхем, X11.

| Метод | Пикселей |
|---|---|
| Уравнение | 793 |
| Параметрическое | 832 |
| Брезенхем | 793 |
| X11 PolyArc | 793 |

Попарное число несовпадающих позиций (XOR):

| Метод | Уравн. | Парам. | Брез. | X11 |
|---|---|---|---|---|
| Уравн. | 0 | 317 | 0 | 0 |
| Парам. | 317 | 0 | 317 | 317 |
| Брез. | 0 | 317 | 0 | 0 |
| X11 | 0 | 317 | 0 | 0 |

В данном опыте уравнение, Брезенхем и X11 совпали побитно. Параметрический метод отличается от каждого из них в 317 позициях. Это число больше разности количества пикселей, поскольку часть позиций есть только в одном контуре, а часть — только в другом. Всего в объединении 971 позиций, в пересечении всех методов — 654, различающихся — 317.

Различия объясняются разными правилами выбора отсчётов. Уравнение и Брезенхем в этом примере выбирают одни и те же ближайшие пиксели октанта. Параметрический метод равномерно шагает по углу и соединяет округлённые отсчёты, что меняет лестницу и может утолщать контур. Отличие в один пиксель становится заметным при увеличении. Нельзя делать вывод о скорости методов только по количеству выведенных пикселей: исследование времени здесь не выполнялось.

Рисунок 10 — Карта различий: красные позиции различаются, серые общие

![Рисунок 10 — Карта различий: красные позиции различаются, серые общие](../images/difference.png)

Рисунок 11 — Один участок 32×32: уравнение, параметрическое, Брезенхем, X11 (слева направо, сверху вниз)

![Рисунок 11 — Один участок 32×32: уравнение, параметрическое, Брезенхем, X11 (слева направо, сверху вниз)](../images/zoom.png)

Рисунок 12 — Реальное настольное окно с четырьмя результатами

![Рисунок 12 — Реальное настольное окно с четырьмя результатами](interface.png)

Снимок получен с X-сервера Xvfb при запуске готового бинарника. Интеграционный тест открыл PNG через диалог, заменил ширину 180 на 280 с помощью событий клавиатуры, нажал построение и сохранение, затем сравнил четыре записанных изображения с результатами вычислительного ядра и настоящего X11-примитива. Снимок не является нарисованным макетом интерфейса.

Рисунок 13 — Режим сравнения, увеличенный участок и загруженный фон

![Рисунок 13 — Режим сравнения, увеличенный участок и загруженный фон](interface-comparison.png)

## 4.2 Дополнительная проверка окружности

Для выполнения общего требования о независимом задании центра и радиуса предусмотрен режим «Окружность». При центре (320;240) и радиусе 140 получены следующие результаты:

| Метод | Пикселей |
|---|---|
| Уравнение | 792 |
| Параметрическое | 824 |
| Брезенхем | 792 |
| X11 PolyArc | 792 |

На этой окружности уравнение, Брезенхем и X11 также совпали; XOR с параметрическим методом равен 80. Эта дополнительная проверка не заменяет индивидуальное задание с треугольником Рёло.

Рисунок 14 — Карта различий для окружности радиуса 140

![Рисунок 14 — Карта различий для окружности радиуса 140](../images/circle/difference.png)

## 4.3 Проверки и воспроизведение

Успешно выполнены 10 тестов. Проверены геометрия и постоянная ширина, связность и радиальная погрешность собственных контуров на нескольких радиусах и ширинах, симметрия, перенос, наличие общих вершин, целочисленный инвариант Брезенхема, отсечение, сохранение исходного фона, ошибки параметров и файлов, PNG, готовый X11-примитив и реальное окно. Команда go vet завершилась без замечаний. Протоколы находятся в validation.

Подготовлены статические ELF-файлы Linux amd64 и arm64, собранные с CGO_ENABLED=0. Установка Go, Python, браузера, GTK/Qt или доступа к интернету для запуска не требуется. Нужен графический сеанс X11 или Wayland с XWayland. Четвёртый метод использует X-сервер, поэтому даже консольный режим полного сравнения требует DISPLAY. В облачной среде для проверки применён Xvfb; на обычном рабочем столе используется имеющийся сервер.

AMD64-бинарник проверен с PATH=/nonexistent: дочерние команды не запускаются, создаются только соединения с локальным X-сервером. Все семь PNG совпали с результатами обычного запуска. Это проверка независимости от Go и внешних команд, но не отдельный контейнер без Go. ARM64 кросс-компилирована и проверена по формату ELF; выполнение на ARM64-оборудовании здесь не проводилось.

Для запуска окна из каталога работы: ./bin/lab4-linux-amd64. Если архиватор снял право исполнения: chmod +x bin/lab4-linux-amd64. Для обработки без показа окна в имеющемся графическом сеансе: ./bin/lab4-linux-amd64 -mode batch -size 280 -cx 320 -cy 240 -out output. Для чтения фона добавляется -source путь_к_файлу.png. Для окружности задаются -shape circle -radius 140. В каталоге результатов сохраняются четыре изображения методов, наложение, карта различий, увеличенный фрагмент и metrics.json.

# 5 Ответы на контрольные вопросы

## 1. Что такое пиксель?

Пиксель — элемент дискретного двумерного растра с целочисленной позицией и значением яркости или цвета. Он является отсчётом изображения; квадратная клетка при увеличении — способ его отображения, а не обязательная физическая форма. В данной программе пиксель результата хранит три 8-битные компоненты RGB и непрозрачный альфа-канал. Координаты допустимы в пределах 0 ≤ x < W и 0 ≤ y < H.

## 2. Что такое растровое изображение?

Растровое изображение — двумерная прямоугольная сетка пикселей, задающая дискретное распределение цвета или яркости. Оно характеризуется шириной и высотой в пикселях, цветовой моделью, разрядностью компонентов и способом хранения. В отличие от векторного описания, содержащего геометрические примитивы, растр непосредственно хранит отсчёты. При увеличении видна конечная пространственная дискретизация; сглаживание и интерполяция меняют способ отображения, но не создают утраченные геометрические данные.

## 3. Для чего нужны алгоритмы растеризации окружностей?

Окружность в непрерывной геометрии содержит бесконечно много точек с вещественными координатами. Растровый экран или файл допускает конечный набор целочисленных позиций. Алгоритм растеризации выбирает пиксели, приближающие идеальную границу, обеспечивает симметрию, связность и контролируемую погрешность при разумном количестве вычислений. Для дуг дополнительно ограничивается угловой диапазон, а для составной фигуры согласуются общие концы. В варианте 8 такая процедура нужна для трёх дуг, образующих треугольник Рёло.

## 4. Какие ещё алгоритмы растеризации окружностей существуют?

Кроме прямого вычисления уравнения, параметрического подхода и Брезенхема применяют метод средней точки, инкрементальные методы цифрового дифференциального анализатора и методы покрытия пикселей со сглаживанием. Метод средней точки анализирует знак неявной функции в точке между кандидатами и тесно связан с целочисленными вариантами Брезенхема. В инкрементальном параметрическом методе координаты обновляют по рекуррентным формулам поворота вместо повторного вычисления синуса и косинуса, при этом контролируют накопление ошибки. Сглаживающие методы, например адаптация подхода Ву к окружностям, распределяют интенсивность между соседними пикселями. Supersampling строит изображение на более плотной сетке и усредняет покрытие. Графические библиотеки также могут аппроксимировать дуги кривыми Безье и растеризовать полученный путь. Эти подходы различаются стоимостью вычислений, точностью и качеством сглаживания; в данной работе реализованы требуемые четыре способа без сглаживания сохранённых контуров.

# Вывод

В ходе выполненной работы, мы изучили алгоритмы растеризации окружностей, создали программу для визуализации работы алгоритмов.
