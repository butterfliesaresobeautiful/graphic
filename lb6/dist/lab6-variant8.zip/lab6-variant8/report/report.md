# Титульный лист

Минобрнауки России

Юго-Западный государственный университет

Кафедра программной инженерии

ОТЧЁТ

по лабораторной работе № 6

по дисциплине «Компьютерная графика»

«Геометрические преобразования»

Индивидуальный номер 28. Вариант 8

Выполнил: студент группы __________

ФИО ____________________________

Проверил: _______________________

Курск 2026 г.

# 1 Формулировка задачи

## Цель работы

освоение навыков обработки растровых изображений с помощью алгоритмических языков программирования путём преобразования координат пикселей.

## Индивидуальное задание

Источник: Ефремов В. В., Ефремова И. Н., Петрик Е. А. Компьютерная графика: введение в обработку изображений: практикум. Курск: ЮЗГУ, 2024. Лабораторная работа № 6 расположена на с. 115–128. Задание и содержание отчёта приведены на с. 119–120, таблица вариантов — на с. 121, контрольные вопросы — на с. 122.

Максимальный номер в таблице — 20. По заданной схеме выбора индивидуальному номеру 28 соответствует вариант 28 % 20 = 8. В строке 8 указаны аффинные преобразования «Поворот, отражение» и функциональное преобразование координат:

i = x′^(5/3),   j = y′.

Требуется разработать алгоритм и программу, выполняющую загрузку изображения из файла, прямое и обратное аффинные преобразования, функциональное преобразование координат и сохранение результатов в файл. Восстановление должно использовать растр, полученный после аффинного преобразования. Необходимо ответить на пять контрольных вопросов и представить исходное и преобразованные изображения.

Для демонстрации выбраны угол 30° и отражение относительно вертикальной оси через центр изображения. Сначала выполняется поворот, затем отражение. Программа позволяет изменять угол и выбирать вертикальную либо горизонтальную центральную ось. Вариант 8 не содержит дополнительного масштабирования; уменьшение вдвое из примера варианта 0 не применяется.

## Параметры реализации

Программа написана на Go. Графический интерфейс представляет собой отдельное окно Linux, работающее через протокол X11; в сеансе Wayland необходим XWayland. Готовый статический исполняемый файл содержит код, шрифт и зависимости. Установка Go, браузера, Python или графических библиотек разработки для запуска не требуется. Консольный режим использует то же вычислительное ядро и работает без графического сеанса.

Входные форматы — PNG, JPEG и GIF (первый кадр); результат сохраняется в PNG. После декодирования используется непрозрачный 8-битный RGB: прозрачные пиксели компонуются с белым фоном, компоненты большей разрядности приводятся к 8 битам. Размер каждой стороны ограничен 4096 пикселями, площадь — 16 000 000 пикселей, входной файл — 32 МиБ. Проверяются конечность угла, допустимость оси, доступность файлов и возможность записи.

# 2 Алгоритм

## 2.1 Система координат и аффинная матрица

Начало растровой системы находится в левом верхнем углу, X направлена вправо, Y — вниз. Центры пикселей имеют целочисленные координаты: 0 ≤ x < W, 0 ≤ y < H. Поворот производится вокруг C = ((W − 1)/2; (H − 1)/2). Положительный угол соответствует повороту по часовой стрелке на экране. Для исходного растра 640×420 центр C = (319,5; 209,5).

R(θ) = [cos θ, −sin θ; sin θ, cos θ],   Sᵥ = [−1, 0; 0, 1].

q = C + Sᵥ R(θ)(p − C) = M p + t,   t = C − M C.

Здесь p — координаты исходного пикселя, q — координаты после преобразования. Отражение относительно горизонтальной оси задаётся Sₕ = [1, 0; 0, −1]. Перенос t служит только для задания центра поворота и отражения. Для вертикальной оси и θ = 30° получаем:

M = [−0,866025404, 0,5; 0,5, 0,866025404],

t = (491,445116509; −131,682322093).

В коде аффинная матрица хранится шестью коэффициентами: x₂ = A x₁ + B y₁ + C, y₂ = D x₁ + E y₁ + F. Символы C и F здесь обозначают коэффициенты смещения, а не точку центра из предыдущей формулы. Определитель Δ = AE − BD. При Δ = 0 обратная матрица не существует; программа также отвергает численно вырожденные матрицы с |Δ| < 10⁻¹².

x₁ = (E x₂ − B y₂ + BF − EC) / Δ,

y₁ = (−D x₂ + A y₂ + DC − AF) / Δ.

Для выбранного сочетания поворота и отражения Δ = −1. Его линейная матрица удовлетворяет M² = I; преобразование относительно того же центра является обратным самому себе. Несмотря на это частное свойство, программа вычисляет общую обратную матрицу по приведённой формуле.

## 2.2 Обратное отображение растра

Прямое геометрическое преобразование и способ заполнения пикселей — разные операции. Перебор только исходных точек с записью в округлённые позиции результата может оставить пропуски. Поэтому для каждого пикселя результата вычисляются координаты источника через обратную функцию, как рекомендовано на с. 119. Координаты округляются к ближайшему целому, после чего копируются R, G, B. Если округлённая точка находится вне источника, пиксель остаётся белым.

T(q) = S(round(A⁻¹(q))),

Sвосст(p) = T(round(A(p))).

В этих формулах A обозначает всё аффинное преобразование с переносом; S — исходный растр, T — аффинный. Процедура Warp всегда принимает прямую геометрическую матрицу и сама обращает её для выборки. Поэтому при восстановлении вызывается Warp(T, A⁻¹): координаты берутся по A, а цвета читаются исключительно из T. Скрытого копирования исходника при восстановлении нет.

Размер холста во всех операциях сохраняется. Участки за его границами отсекаются. Повторное округление и отсечение приводят к потере информации, поэтому геометрическая обратимость не означает точного восстановления цифрового изображения. Билинейная интерполяция могла бы уменьшить ступенчатость, но смешивала бы цвета и не восстановила бы обрезанные части; здесь выбран метод ближайшего соседа для прозрачной попиксельной реализации.

## 2.3 Функциональное преобразование

i = x′^(5/3),   j = y′;   x′ = i^(3/5),   y′ = j.

Вычисление выполняется по обратной функции для каждого целого i, j результата. Координаты выражены в пикселях без нормирования к интервалу [0;1] и без дополнительного коэффициента масштаба: это буквальная формула строки 8. Для вещественных отрицательных аргументов вспомогательные функции используют знак и модуль, что соответствует нечётному корню; на данном холсте координаты неотрицательны.

При W = 640 крайняя координата результата i = 639 соответствует x′ = 639^(3/5) ≈ 48,228. После округления видны исходные столбцы 0…48. Нелинейный результат сильно растягивает левую часть исходника, а остальные части оказываются вне фиксированного холста. Это свойство заданной функции и выбранного размера, а не ошибка заполнения. Во всех 268 800 пикселях результата находятся допустимые отсчёты источника.

## 2.4 Схемы алгоритмов

На рисунке 1 показана последовательность трёх преобразований. Обозначения S и T соответствуют исходному и аффинному растрам. На рисунке 2 раскрыта общая выборка по обратной функции. Овалы обозначают начало и конец, параллелограммы — ввод и вывод, прямоугольники — действия, ромбы — условия. В интерфейсе операции доступны также по отдельности.

Рисунок 1 — Общий алгоритм геометрических преобразований

![Рисунок 1 — Общий алгоритм геометрических преобразований](algorithm-main.png)

Рисунок 2 — Попиксельная выборка по обратной функции

![Рисунок 2 — Попиксельная выборка по обратной функции](algorithm-sampling.png)

# 3 Программа на алгоритмическом языке программирования

Ниже приведён полный собственный исходный код приложения, включая графический интерфейс, вычислительное ядро, генератор демонстрационного растра и тесты. Код зависимостей X11 и шрифтового движка поставляется отдельно в каталоге vendor вместе с лицензиями и не дублируется в листингах. Для приложения используется только Go; Python-скрипты в tools обслуживают исключительно оформление отчёта и схем.

Файлы cmd/lab6 задают режимы запуска; internal/raster содержит чтение и запись изображений и математику; internal/desktop создаёт окно, диалог выбора файла, поля параметров и кнопки. Четыре панели показывают источник, аффинный результат, восстановление и функциональное преобразование. Изменение полей не меняет ранее сохранённую матрицу: восстановление использует параметры фактически выполненного аффинного преобразования.

## Листинг 3.1 — go.mod

```go
module graphiclabs/lb6

go 1.22

require (
	github.com/jezek/xgb v1.1.1
	golang.org/x/image v0.24.0
)

require golang.org/x/text v0.22.0 // indirect
```

## Листинг 3.2 — cmd/lab6/main.go

```go
package main

import (
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"image"
	"os"
	"path/filepath"

	"graphiclabs/lb6/internal/desktop"
	"graphiclabs/lb6/internal/raster"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "Ошибка:", err)
		os.Exit(1)
	}
}

func run(args []string) error {
	f := flag.NewFlagSet("lab6", flag.ContinueOnError)
	mode := f.String("mode", "gui", "gui: окно X11; batch: обработка; demo: пример")
	source := f.String("source", "", "исходный PNG, JPEG или GIF")
	out := f.String("out", "output", "каталог результатов PNG")
	angle := f.Float64("angle", 30, "угол в градусах по часовой стрелке")
	axis := f.String("axis", "vertical", "ось отражения: vertical или horizontal")
	if err := f.Parse(args); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return nil
		}
		return err
	}
	if f.NArg() != 0 {
		return errors.New("неожиданные позиционные аргументы")
	}
	if *mode != "gui" && *mode != "batch" && *mode != "demo" {
		return errors.New("режим: gui, batch или demo")
	}
	if _, err := raster.Variant8(1, 1, *angle, *axis); err != nil {
		return err
	}
	var src *image.RGBA
	var err error
	if *source != "" {
		src, err = raster.Load(*source)
		if err != nil {
			return err
		}
	} else {
		if *mode == "batch" {
			return errors.New("для batch укажите -source")
		}
		src = raster.Demo()
	}
	if *mode == "gui" {
		if *out == "output" {
			exe, err := os.Executable()
			if err != nil {
				return err
			}
			base := filepath.Dir(exe)
			if filepath.Base(base) == "bin" {
				base = filepath.Dir(base)
			}
			*out = filepath.Join(base, "output")
		}
		return desktop.Run(src, *source, *out, *angle, *axis)
	}
	r, err := raster.Process(src, *angle, *axis)
	if err != nil {
		return err
	}
	if err = os.MkdirAll(*out, 0755); err != nil {
		return err
	}
	outputs := []struct {
		name string
		img  image.Image
	}{
		{"affine.png", r.Affine}, {"restored.png", r.Restored}, {"nonlinear.png", r.Nonlinear},
	}
	if *mode == "demo" {
		outputs = append(outputs, struct {
			name string
			img  image.Image
		}{"source.png", src})
	}
	for _, item := range outputs {
		if *source != "" {
			a, _ := filepath.Abs(*source)
			b, _ := filepath.Abs(filepath.Join(*out, item.name))
			if a == b {
				return errors.New("выходной файл совпадает с исходным: выберите другой каталог")
			}
		}
	}
	for _, item := range outputs {
		if err = raster.Save(filepath.Join(*out, item.name), item.img); err != nil {
			return err
		}
	}
	mae, _ := raster.MAE(src, r.Restored)
	metrics := struct {
		Lab, Individual, Variant int
		Angle                    float64
		Axis                     string
		Width, Height            int
		Matrix                   raster.Matrix
		Stats                    [3]raster.Stats
		RestorationMAE           float64
	}{6, 28, 28 % 20, *angle, *axis, src.Rect.Dx(), src.Rect.Dy(), r.Matrix, r.Stats, mae}
	data, err := json.MarshalIndent(metrics, "", "  ")
	if err != nil {
		return err
	}
	if err = os.WriteFile(filepath.Join(*out, "metrics.json"), append(data, '\n'), 0644); err != nil {
		return err
	}
	fmt.Printf("ЛБ6, вариант 28 %% 20 = 8. PNG сохранены: %s\n", *out)
	fmt.Printf("Угол: %g°; отражение: %s; MAE восстановления RGB: %.6f\n", *angle, *axis, mae)
	return nil
}
```

## Листинг 3.3 — internal/raster/image.go

```go
// Package raster implements the RGB file operations for lab 6.
package raster

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"image/color"
	_ "image/gif"
	_ "image/jpeg"
	"image/png"
	"io"
	"os"
	"path/filepath"
)

const MaxSide = 4096
const MaxPixels = 16_000_000
const MaxFile = 32 << 20

func Dimensions(w, h int) error {
	if w < 1 || h < 1 || w > MaxSide || h > MaxSide || w*h > MaxPixels {
		return fmt.Errorf("размеры: 1…%d, не более %d пикселей", MaxSide, MaxPixels)
	}
	return nil
}

// New returns an opaque white canvas, including every boundary pixel.
func New(w, h int) (*image.RGBA, error) {
	if err := Dimensions(w, h); err != nil {
		return nil, err
	}
	m := image.NewRGBA(image.Rect(0, 0, w, h))
	for i := range m.Pix {
		m.Pix[i] = 255
	}
	return m, nil
}

// Decode limits input and allocation before decoding. Transparency is composed
// over white; opaque RGB values are unchanged. GIF uses its first frame.
func Decode(r io.Reader) (*image.RGBA, error) {
	data, err := io.ReadAll(io.LimitReader(r, MaxFile+1))
	if err != nil {
		return nil, err
	}
	if len(data) > MaxFile {
		return nil, errors.New("файл больше 32 МиБ")
	}
	cfg, _, err := image.DecodeConfig(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("ожидается PNG, JPEG или GIF: %w", err)
	}
	if err = Dimensions(cfg.Width, cfg.Height); err != nil {
		return nil, err
	}
	src, _, err := image.Decode(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("повреждённое изображение: %w", err)
	}
	dst, _ := New(cfg.Width, cfg.Height)
	for y := 0; y < cfg.Height; y++ {
		for x := 0; x < cfg.Width; x++ {
			r, g, b, a := src.At(x+src.Bounds().Min.X, y+src.Bounds().Min.Y).RGBA()
			dst.SetRGBA(x, y, color.RGBA{
				uint8((r + 65535 - a) >> 8),
				uint8((g + 65535 - a) >> 8),
				uint8((b + 65535 - a) >> 8), 255,
			})
		}
	}
	return dst, nil
}

func Load(path string) (*image.RGBA, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("открытие: %w", err)
	}
	defer f.Close()
	return Decode(f)
}

// Save writes PNG atomically; a failed encode does not truncate an old result.
func Save(path string, m image.Image) error {
	if m == nil {
		return errors.New("нет изображения для сохранения")
	}
	f, err := os.CreateTemp(filepath.Dir(path), ".lab2-*.tmp")
	if err != nil {
		return fmt.Errorf("создание файла: %w", err)
	}
	defer os.Remove(f.Name())
	if err = png.Encode(f, m); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(f.Name(), path)
}
```

## Листинг 3.4 — internal/raster/transform.go

```go
package raster

import (
	"errors"
	"fmt"
	"image"
	"math"
)

// Matrix maps source pixel centres to destination pixel centres.
// [x2;y2] = [A B;D E] [x1;y1] + [C;F].
type Matrix struct{ A, B, C, D, E, F float64 }

func (m Matrix) Point(x, y float64) (float64, float64) {
	return m.A*x + m.B*y + m.C, m.D*x + m.E*y + m.F
}

func (m Matrix) Inverse() (Matrix, error) {
	for _, v := range []float64{m.A, m.B, m.C, m.D, m.E, m.F} {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return Matrix{}, errors.New("матрица содержит нечисловые значения")
		}
	}
	det := m.A*m.E - m.B*m.D
	if math.Abs(det) < 1e-12 {
		return Matrix{}, errors.New("вырожденная матрица: обратного преобразования нет")
	}
	return Matrix{m.E / det, -m.B / det, (m.B*m.F - m.E*m.C) / det,
		-m.D / det, m.A / det, (m.C*m.D - m.A*m.F) / det}, nil
}

// Variant8 first rotates clockwise in screen coordinates, then reflects
// about the chosen central axis. No extra scaling or translation is added.
func Variant8(w, h int, angle float64, axis string) (Matrix, error) {
	if err := Dimensions(w, h); err != nil {
		return Matrix{}, err
	}
	if math.IsNaN(angle) || math.IsInf(angle, 0) || angle < -360 || angle > 360 {
		return Matrix{}, errors.New("угол должен быть конечным числом от −360 до 360 градусов")
	}
	sx, sy := 1.0, 1.0
	switch axis {
	case "vertical":
		sx = -1
	case "horizontal":
		sy = -1
	default:
		return Matrix{}, errors.New("ось отражения: vertical или horizontal")
	}
	c, s := math.Cos(angle*math.Pi/180), math.Sin(angle*math.Pi/180)
	m := Matrix{A: sx * c, B: -sx * s, D: sy * s, E: sy * c}
	cx, cy := float64(w-1)/2, float64(h-1)/2
	m.C = cx - m.A*cx - m.B*cy
	m.F = cy - m.D*cx - m.E*cy
	return m, nil
}

type Stats struct {
	Mapped  int `json:"mapped"`
	Outside int `json:"outside"`
}

// sample visits every destination pixel. Rounding is nearest-neighbour.
// Out-of-range samples keep the white background, with no out-of-bounds reads.
func sample(src *image.RGBA, back func(float64, float64) (float64, float64)) (*image.RGBA, Stats, error) {
	var st Stats
	if src == nil || src.Bounds().Empty() {
		return nil, st, errors.New("сначала загрузите изображение")
	}
	b := src.Bounds()
	dst, err := New(b.Dx(), b.Dy())
	if err != nil {
		return nil, st, err
	}
	for y := 0; y < b.Dy(); y++ {
		for x := 0; x < b.Dx(); x++ {
			u, v := back(float64(x), float64(y))
			u, v = math.Round(u), math.Round(v)
			if math.IsNaN(u) || math.IsNaN(v) || u < 0 || v < 0 || u >= float64(b.Dx()) || v >= float64(b.Dy()) {
				st.Outside++
				continue
			}
			dst.SetRGBA(x, y, src.RGBAAt(int(u)+b.Min.X, int(v)+b.Min.Y))
			st.Mapped++
		}
	}
	return dst, st, nil
}

// Warp implements a forward geometric transform using inverse raster mapping.
func Warp(src *image.RGBA, forward Matrix) (*image.RGBA, Stats, error) {
	back, err := forward.Inverse()
	if err != nil {
		return nil, Stats{}, err
	}
	return sample(src, back.Point)
}

// Power53 is the real-valued odd-root interpretation, also defined for x<0.
func Power53(x float64) float64 { return math.Copysign(math.Pow(math.Abs(x), 5.0/3.0), x) }
func Power35(x float64) float64 { return math.Copysign(math.Pow(math.Abs(x), 3.0/5.0), x) }

// Nonlinear uses the exact variant formula i=x'^(5/3), j=y'.
// Pixel coordinates are NOT normalised. The canvas keeps its original size.
func Nonlinear(src *image.RGBA) (*image.RGBA, Stats, error) {
	return sample(src, func(i, j float64) (float64, float64) { return Power35(i), j })
}

type Results struct {
	Affine, Restored, Nonlinear *image.RGBA
	Matrix                      Matrix
	Stats                       [3]Stats
}

func Process(src *image.RGBA, angle float64, axis string) (Results, error) {
	var r Results
	if src == nil {
		return r, errors.New("не задан источник")
	}
	m, err := Variant8(src.Bounds().Dx(), src.Bounds().Dy(), angle, axis)
	if err != nil {
		return r, err
	}
	r.Matrix = m
	r.Affine, r.Stats[0], err = Warp(src, m)
	if err != nil {
		return r, err
	}
	inv, err := m.Inverse()
	if err != nil {
		return r, err
	}
	// Restoration reads the transformed raster, never the original image.
	r.Restored, r.Stats[1], err = Warp(r.Affine, inv)
	if err != nil {
		return r, err
	}
	r.Nonlinear, r.Stats[2], err = Nonlinear(src)
	return r, err
}

func MAE(a, b *image.RGBA) (float64, error) {
	if a == nil || b == nil || a.Bounds() != b.Bounds() {
		return 0, fmt.Errorf("для сравнения нужны одинаковые размеры")
	}
	var sum float64
	for y := a.Rect.Min.Y; y < a.Rect.Max.Y; y++ {
		for x := a.Rect.Min.X; x < a.Rect.Max.X; x++ {
			p, q := a.RGBAAt(x, y), b.RGBAAt(x, y)
			sum += math.Abs(float64(p.R)-float64(q.R)) + math.Abs(float64(p.G)-float64(q.G)) + math.Abs(float64(p.B)-float64(q.B))
		}
	}
	return sum / float64(a.Rect.Dx()*a.Rect.Dy()*3), nil
}
```

## Листинг 3.5 — internal/raster/demo.go

```go
package raster

import (
	"image"
	"image/color"
	"math"
)

// Demo creates an asymmetric RGB calibration scene entirely in Go.
// Fine detail on the left makes the literal nonlinear stretching visible.
func Demo() *image.RGBA {
	m, _ := New(640, 420)
	for y := 0; y < 420; y++ {
		for x := 0; x < 640; x++ {
			c := color.RGBA{uint8(40 + x/4), uint8(80 + y/3), uint8(190 - y/5), 255}
			if x%40 == 0 || y%40 == 0 {
				c = color.RGBA{220, 230, 244, 255}
			}
			if x < 64 {
				palette := []color.RGBA{{237, 70, 80, 255}, {255, 192, 60, 255}, {44, 180, 120, 255}, {35, 109, 220, 255}}
				c = palette[(x/8+y/30)%len(palette)]
				if x%8 == 0 || y%30 == 0 {
					c = color.RGBA{25, 35, 55, 255}
				}
			}
			// House, roof and asymmetric windows.
			if x >= 130 && x <= 340 && y >= 190 && y <= 350 {
				c = color.RGBA{242, 178, 92, 255}
			}
			if y >= 90 && y < 190 && math.Abs(float64(x-235)) < float64(y-90)*1.25 {
				c = color.RGBA{172, 54, 72, 255}
			}
			if x > 155 && x < 205 && y > 220 && y < 270 {
				c = color.RGBA{99, 211, 238, 255}
			}
			if x > 265 && x < 310 && y > 250 && y < 350 {
				c = color.RGBA{68, 75, 102, 255}
			}
			if (x-505)*(x-505)+(y-110)*(y-110) < 62*62 {
				c = color.RGBA{255, 210, 62, 255}
			}
			if (x-510)*(x-510)+(y-290)*(y-290) < 55*55 {
				c = color.RGBA{65, 193, 133, 255}
			}
			if x > 490 && x < 505 && y > 260 && y < 380 {
				c = color.RGBA{92, 60, 53, 255}
			}
			// White arrow to the right, visibly reversed after reflection.
			if y >= 35 && y <= 48 && x >= 120 && x < 270 || x >= 260 && x <= 290 && math.Abs(float64(y-42)) <= float64(290-x) {
				c = color.RGBA{255, 255, 255, 255}
			}
			m.SetRGBA(x, y, c)
		}
	}
	return m
}
```

## Листинг 3.6 — internal/desktop/window.go

```go
// Package desktop is a native X11 client written in Go, without CGO.
package desktop

import (
	_ "embed"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"os"

	"github.com/jezek/xgb"
	"github.com/jezek/xgb/xproto"
	xdraw "golang.org/x/image/draw"
	"golang.org/x/image/font"
	"golang.org/x/image/font/opentype"
	"golang.org/x/image/math/fixed"

	"graphiclabs/lb6/internal/raster"
)

//go:embed assets/DejaVuSans.ttf
var fontData []byte

const frameW, frameH = 1200, 840

type button struct {
	rect          image.Rectangle
	label, action string
}
type app struct {
	conn                                 *xgb.Conn
	win                                  xproto.Window
	gc                                   xproto.Gcontext
	screen                               *xproto.ScreenInfo
	wmDelete                             xproto.Atom
	keys                                 *xproto.GetKeyboardMappingReply
	minKey                               xproto.Keycode
	width, height                        int
	faces                                map[int]font.Face
	buttons                              []button
	source                               *image.RGBA
	results                              raster.Results
	sourcePath, out, angle, axis, status string
	focus                                int
	selectAll                            bool
	dialog, dir, dirInput                string
	entries                              []os.DirEntry
	page                                 int
}

func Run(src *image.RGBA, sourcePath, out string, angle float64, axis string) error {
	c, err := xgb.NewConn()
	if err != nil {
		return fmt.Errorf("не удалось открыть окно X11: %w; для работы без экрана используйте -mode batch", err)
	}
	defer c.Close()
	setup := xproto.Setup(c)
	screen := setup.DefaultScreen(c)
	valid := false
	for _, depth := range screen.AllowedDepths {
		for _, v := range depth.Visuals {
			if v.VisualId == screen.RootVisual && v.RedMask == 0xff0000 && v.GreenMask == 0xff00 && v.BlueMask == 0xff {
				valid = true
			}
		}
	}
	bpp := byte(0)
	for _, f := range setup.PixmapFormats {
		if f.Depth == screen.RootDepth {
			bpp = f.BitsPerPixel
		}
	}
	if !valid || bpp != 32 || setup.ImageByteOrder != xproto.ImageOrderLSBFirst {
		return errors.New("нужен X11 TrueColor с 32-битными пикселями LSBFirst (обычный Linux desktop)")
	}
	win, err := xproto.NewWindowId(c)
	if err != nil {
		return err
	}
	gc, err := xproto.NewGcontextId(c)
	if err != nil {
		return err
	}
	a := &app{conn: c, win: win, gc: gc, screen: screen, source: src, sourcePath: sourcePath,
		out: out, angle: fmt.Sprintf("%g", angle), axis: axis, faces: map[int]font.Face{},
		status: "Откройте файл или используйте демонстрацию. Вариант 28 % 20 = 8.", focus: 1,
		width: min(frameW, int(screen.WidthInPixels)-40), height: min(frameH, int(screen.HeightInPixels)-80)}
	if a.width < 480 || a.height < 400 {
		return errors.New("для окна требуется экран не менее 520×480")
	}
	fontFile, err := opentype.Parse(fontData)
	if err != nil {
		return err
	}
	for _, size := range []int{14, 16, 18, 26} {
		face, e := opentype.NewFace(fontFile, &opentype.FaceOptions{Size: float64(size), DPI: 72, Hinting: font.HintingFull})
		if e != nil {
			return e
		}
		a.faces[size] = face
		defer face.Close()
	}
	a.minKey = setup.MinKeycode
	a.keys, err = xproto.GetKeyboardMapping(c, setup.MinKeycode, byte(int(setup.MaxKeycode)-int(setup.MinKeycode)+1)).Reply()
	if err != nil {
		return err
	}
	mask := uint32(xproto.EventMaskExposure | xproto.EventMaskButtonPress | xproto.EventMaskKeyPress | xproto.EventMaskStructureNotify)
	err = xproto.CreateWindowChecked(c, screen.RootDepth, win, screen.Root, 0, 0, uint16(a.width), uint16(a.height), 0,
		xproto.WindowClassInputOutput, screen.RootVisual, xproto.CwBackPixel|xproto.CwEventMask, []uint32{screen.WhitePixel, mask}).Check()
	if err != nil {
		return err
	}
	defer xproto.DestroyWindow(c, win)
	if err = xproto.CreateGCChecked(c, gc, xproto.Drawable(win), 0, nil).Check(); err != nil {
		return err
	}
	defer xproto.FreeGC(c, gc)
	title := "Lab6 - Geometric transformations - Variant 8"
	xproto.ChangeProperty(c, xproto.PropModeReplace, win, xproto.AtomWmName, xproto.AtomString, 8, uint32(len(title)), []byte(title))
	protocols, e := xproto.InternAtom(c, false, 12, "WM_PROTOCOLS").Reply()
	if e != nil {
		return e
	}
	closeAtom, e := xproto.InternAtom(c, false, 16, "WM_DELETE_WINDOW").Reply()
	if e != nil {
		return e
	}
	a.wmDelete = closeAtom.Atom
	data := make([]byte, 4)
	xgb.Put32(data, uint32(closeAtom.Atom))
	xproto.ChangeProperty(c, xproto.PropModeReplace, win, protocols.Atom, xproto.AtomAtom, 32, 1, data)
	if err = xproto.MapWindowChecked(c, win).Check(); err != nil {
		return err
	}
	if err = a.paint(); err != nil {
		return err
	}
	for {
		event, e := c.WaitForEvent()
		if e != nil {
			return e
		}
		if event == nil {
			return nil
		}
		switch ev := event.(type) {
		case xproto.ClientMessageEvent:
			if ev.Data.Data32[0] == uint32(a.wmDelete) {
				return nil
			}
		case xproto.DestroyNotifyEvent:
			return nil
		case xproto.ConfigureNotifyEvent:
			a.width, a.height = int(ev.Width), int(ev.Height)
		case xproto.ExposeEvent:
			if ev.Count != 0 {
				continue
			}
		case xproto.ButtonPressEvent:
			x, y := a.toFrame(int(ev.EventX), int(ev.EventY))
			a.click(x, y, ev.Detail)
		case xproto.KeyPressEvent:
			a.key(ev)
		default:
			continue
		}
		if err = a.paint(); err != nil {
			return err
		}
	}
}

func (a *app) viewport() image.Rectangle {
	scale := min(float64(a.width)/frameW, float64(a.height)/frameH)
	w, h := int(frameW*scale), int(frameH*scale)
	x, y := (a.width-w)/2, (a.height-h)/2
	return image.Rect(x, y, x+w, y+h)
}
func (a *app) toFrame(x, y int) (int, int) {
	r := a.viewport()
	if r.Empty() {
		return -1, -1
	}
	return (x - r.Min.X) * frameW / r.Dx(), (y - r.Min.Y) * frameH / r.Dy()
}

func (a *app) paint() error {
	if a.width < 1 || a.height < 1 || a.width > 8192 || a.height > 8192 {
		return nil
	}
	canvas := a.render()
	view := image.NewRGBA(image.Rect(0, 0, a.width, a.height))
	draw.Draw(view, view.Bounds(), image.NewUniform(color.RGBA{231, 236, 243, 255}), image.Point{}, draw.Src)
	xdraw.ApproxBiLinear.Scale(view, a.viewport(), canvas, canvas.Bounds(), draw.Src, nil)
	// X11 PutImage uses B,G,R,pad. Chunk rows to stay below request size limits.
	rows := max(1, (int(xproto.Setup(a.conn).MaximumRequestLength)*4-64)/(a.width*4))
	for y := 0; y < a.height; y += rows {
		n := min(rows, a.height-y)
		buf := make([]byte, a.width*n*4)
		for j := 0; j < n; j++ {
			for x := 0; x < a.width; x++ {
				p := view.RGBAAt(x, y+j)
				k := (j*a.width + x) * 4
				buf[k], buf[k+1], buf[k+2] = p.B, p.G, p.R
			}
		}
		if err := xproto.PutImageChecked(a.conn, xproto.ImageFormatZPixmap, xproto.Drawable(a.win), a.gc,
			uint16(a.width), uint16(n), 0, int16(y), 0, a.screen.RootDepth, buf).Check(); err != nil {
			return err
		}
	}
	return nil
}

func fill(m *image.RGBA, r image.Rectangle, c color.RGBA) {
	draw.Draw(m, r, image.NewUniform(c), image.Point{}, draw.Src)
}
func (a *app) text(m *image.RGBA, x, y, size int, s string, c color.RGBA) {
	d := font.Drawer{Dst: m, Src: image.NewUniform(c), Face: a.faces[size], Dot: fixed.P(x, y)}
	d.DrawString(s)
}
```

## Листинг 3.7 — internal/desktop/ui.go

```go
package desktop

import (
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/jezek/xgb/xproto"
	xdraw "golang.org/x/image/draw"
	"graphiclabs/lb6/internal/raster"
)

var ink = color.RGBA{36, 51, 73, 255}
var blue = color.RGBA{35, 91, 175, 255}
var muted = color.RGBA{87, 105, 129, 255}
var white = color.RGBA{255, 255, 255, 255}

func (a *app) add(m *image.RGBA, r image.Rectangle, label, action string) {
	a.buttons = append(a.buttons, button{r, label, action})
	fill(m, r, blue)
	a.text(m, r.Min.X+12, r.Min.Y+25, 16, label, white)
}

func (a *app) field(m *image.RGBA, r image.Rectangle, text string, id int) {
	c := color.RGBA{186, 198, 214, 255}
	if a.focus == id {
		c = blue
	}
	fill(m, r, c)
	fill(m, r.Inset(2), white)
	// A bounded text viewport; long paths keep their last characters visible.
	limit := r.Dx()/10 - 2
	s := []rune(text)
	if len(s) > limit {
		s = s[len(s)-limit:]
	}
	a.text(m, r.Min.X+8, r.Min.Y+25, 16, string(s), ink)
}

func (a *app) render() *image.RGBA {
	m := image.NewRGBA(image.Rect(0, 0, frameW, frameH))
	a.buttons = nil
	fill(m, m.Bounds(), color.RGBA{240, 244, 249, 255})
	a.text(m, 24, 38, 26, "Геометрические преобразования", ink)
	a.text(m, 24, 64, 14, "Лабораторная 06  /  Индивидуальный номер 28  /  Вариант 08", muted)
	a.add(m, image.Rect(24, 80, 244, 116), "Открыть изображение", "open")
	a.add(m, image.Rect(256, 80, 352, 116), "Демо", "demo")
	a.text(m, 375, 104, 16, "Угол, °", ink)
	a.field(m, image.Rect(452, 80, 542, 116), a.angle, 1)
	ax := "вертикаль"
	if a.axis == "horizontal" {
		ax = "горизонталь"
	}
	a.add(m, image.Rect(562, 80, 846, 116), "Отражение: "+ax, "axis")
	a.text(m, 865, 103, 14, "Положительный угол — по часовой", muted)
	a.add(m, image.Rect(24, 130, 276, 166), "Поворот + отражение", "affine")
	a.add(m, image.Rect(288, 130, 468, 166), "Восстановить", "restore")
	a.add(m, image.Rect(480, 130, 730, 166), "Нелинейное x′^(5/3)", "nonlinear")
	a.add(m, image.Rect(742, 130, 944, 166), "Выполнить всё", "all")
	a.add(m, image.Rect(956, 130, 1176, 166), "Сохранить всё", "save-all")
	a.text(m, 24, 206, 16, "Каталог PNG", ink)
	a.field(m, image.Rect(142, 182, 952, 218), a.out, 2)
	a.add(m, image.Rect(966, 182, 1176, 218), "Выбрать каталог…", "directory")
	for i, line := range wrap(a.status, 118) {
		if i == 2 {
			break
		}
		a.text(m, 24, 245+i*20, 14, line, muted)
	}
	imgs := []*image.RGBA{a.source, a.results.Affine, a.results.Restored, a.results.Nonlinear}
	labels := []string{"1. Исходное изображение", "2. Поворот → отражение", "3. Обратное преобразование", "4. i = x′^(5/3), j = y′"}
	for i, src := range imgs {
		x, y := 24+(i%2)*584, 284+(i/2)*264
		card := image.Rect(x, y, x+568, y+248)
		fill(m, card, white)
		a.text(m, x+12, y+25, 16, labels[i], ink)
		if i > 0 {
			a.add(m, image.Rect(x+400, y+4, x+556, y+38), "Сохранить PNG", fmt.Sprint("save-", i))
		}
		r := image.Rect(x+12, y+46, x+556, y+236)
		fill(m, r, color.RGBA{231, 237, 245, 255})
		if src == nil {
			a.text(m, x+40, y+140, 16, "Результат ещё не сформирован", muted)
			continue
		}
		scale := min(float64(r.Dx())/float64(src.Rect.Dx()), float64(r.Dy())/float64(src.Rect.Dy()))
		w, h := int(float64(src.Rect.Dx())*scale), int(float64(src.Rect.Dy())*scale)
		left, top := r.Min.X+(r.Dx()-w)/2, r.Min.Y+(r.Dy()-h)/2
		xdraw.NearestNeighbor.Scale(m, image.Rect(left, top, left+w, top+h), src, src.Bounds(), draw.Src, nil)
	}
	a.text(m, 24, 832, 14, "RGB · Ближайший сосед · Размер холста сохраняется · Результаты сохраняются без потерь в PNG", muted)
	if a.dialog != "" {
		a.renderDialog(m)
	}
	return m
}

func wrap(s string, n int) []string {
	var lines []string
	for _, word := range strings.Fields(s) {
		if len(lines) == 0 || len([]rune(lines[len(lines)-1]+" "+word)) > n {
			lines = append(lines, word)
		} else {
			lines[len(lines)-1] += " " + word
		}
	}
	return lines
}

func (a *app) click(x, y int, detail xproto.Button) {
	pt := image.Pt(x, y)
	if a.dialog != "" && (detail == 4 || detail == 5) {
		if detail == 4 {
			a.page = max(0, a.page-1)
		} else {
			a.page = min(max(0, (len(a.entries)-1)/16), a.page+1)
		}
		return
	}
	if detail != 1 {
		return
	}
	if a.dialog != "" {
		if pt.In(image.Rect(110, 140, 925, 176)) {
			a.focus = 3
			a.selectAll = true
			return
		}
	} else {
		if pt.In(image.Rect(452, 80, 542, 116)) {
			a.focus = 1
			a.selectAll = true
			return
		}
		if pt.In(image.Rect(142, 182, 952, 218)) {
			a.focus = 2
			a.selectAll = true
			return
		}
	}
	for _, b := range a.buttons {
		if pt.In(b.rect) {
			if err := a.action(b.action); err != nil {
				a.status = "Ошибка: " + err.Error()
			}
			return
		}
	}
}

func (a *app) action(action string) error {
	switch action {
	case "open", "directory":
		a.dialog = action
		a.page = 0
		a.focus = 3
		dir, err := os.Getwd()
		if err != nil {
			return err
		}
		if action == "directory" && a.out != "" {
			dir = a.out
		}
		if action == "open" && a.sourcePath != "" {
			dir = filepath.Dir(a.sourcePath)
		}
		if err = a.readDir(dir); err != nil {
			fallback, _ := os.Getwd()
			return a.readDir(fallback)
		}
	case "close":
		a.dialog = ""
		a.focus = 1
	case "browse":
		return a.readDir(a.dirInput)
	case "parent":
		return a.readDir(filepath.Dir(a.dir))
	case "prev":
		a.page = max(0, a.page-1)
	case "next":
		a.page = min(max(0, (len(a.entries)-1)/16), a.page+1)
	case "choose-dir":
		a.out = a.dir
		a.dialog = ""
		a.focus = 2
	case "demo":
		a.source = raster.Demo()
		a.sourcePath = ""
		a.results = raster.Results{}
		a.status = "Демонстрационный источник: 640×420. Изображение создано средствами Go."
	case "axis":
		if a.axis == "vertical" {
			a.axis = "horizontal"
		} else {
			a.axis = "vertical"
		}
		a.status = "Новая ось будет использована при следующем аффинном преобразовании."
	case "affine", "all":
		angle, err := strconv.ParseFloat(strings.ReplaceAll(a.angle, ",", "."), 64)
		if err != nil {
			return errors.New("введите числовой угол")
		}
		if a.source == nil {
			return errors.New("откройте исходное изображение")
		}
		if action == "all" {
			r, err := raster.Process(a.source, angle, a.axis)
			if err != nil {
				return err
			}
			a.results = r
			a.status = "Выполнены все преобразования. Восстановление рассчитано из аффинного результата."
		} else {
			m, err := raster.Variant8(a.source.Rect.Dx(), a.source.Rect.Dy(), angle, a.axis)
			if err != nil {
				return err
			}
			img, st, err := raster.Warp(a.source, m)
			if err != nil {
				return err
			}
			a.results.Matrix = m
			a.results.Affine = img
			a.results.Restored = nil
			a.results.Stats[0] = st
			a.status = fmt.Sprintf("Угол %g°. Поворот, затем отражение. Выборок вне источника: %d.", angle, st.Outside)
		}
	case "restore":
		if a.results.Affine == nil {
			return errors.New("сначала выполните поворот и отражение")
		}
		inv, err := a.results.Matrix.Inverse()
		if err != nil {
			return err
		}
		img, st, err := raster.Warp(a.results.Affine, inv)
		if err != nil {
			return err
		}
		a.results.Restored = img
		a.results.Stats[1] = st
		a.status = "Восстановлено из преобразованного растра. Округление и обрезка не позволяют вернуть все детали."
	case "nonlinear":
		img, st, err := raster.Nonlinear(a.source)
		if err != nil {
			return err
		}
		a.results.Nonlinear = img
		a.results.Stats[2] = st
		a.status = "Точная формула: i=x′^(5/3), j=y′; обратная выборка x′=i^(3/5). Координаты не нормализованы."
	case "save-all":
		for i := 1; i <= 3; i++ {
			if err := a.save(i); err != nil {
				return err
			}
		}
		a.status = "Три результата сохранены в " + a.out
	default:
		if strings.HasPrefix(action, "entry-") {
			i, err := strconv.Atoi(strings.TrimPrefix(action, "entry-"))
			if err != nil || i < 0 || i >= len(a.entries) {
				return errors.New("неверный файл")
			}
			path := filepath.Join(a.dir, a.entries[i].Name())
			if a.entries[i].IsDir() {
				return a.readDir(path)
			}
			img, err := raster.Load(path)
			if err != nil {
				return err
			}
			a.source = img
			a.sourcePath = path
			a.results = raster.Results{}
			a.dialog = ""
			a.focus = 1
			a.status = fmt.Sprintf("Открыт %s, %d×%d; результаты предыдущего источника очищены.", filepath.Base(path), img.Rect.Dx(), img.Rect.Dy())
		} else if strings.HasPrefix(action, "save-") {
			i, err := strconv.Atoi(strings.TrimPrefix(action, "save-"))
			if err != nil {
				return err
			}
			return a.save(i)
		} else {
			return errors.New("неизвестное действие")
		}
	}
	return nil
}

func (a *app) save(i int) error {
	if i < 1 || i > 3 {
		return errors.New("неверный номер результата")
	}
	imgs := []*image.RGBA{a.results.Affine, a.results.Restored, a.results.Nonlinear}
	if imgs[i-1] == nil {
		return errors.New("сначала сформируйте этот результат")
	}
	if strings.TrimSpace(a.out) == "" {
		return errors.New("выберите каталог для PNG")
	}
	if err := os.MkdirAll(a.out, 0755); err != nil {
		return err
	}
	name := []string{"affine.png", "restored.png", "nonlinear.png"}[i-1]
	path := filepath.Join(a.out, name)
	if a.sourcePath != "" {
		src, _ := filepath.Abs(a.sourcePath)
		dst, _ := filepath.Abs(path)
		if src == dst {
			return errors.New("нельзя перезаписать исходный файл: выберите другой каталог")
		}
	}
	if err := raster.Save(path, imgs[i-1]); err != nil {
		return err
	}
	a.status = "Сохранено: " + path
	return nil
}

func (a *app) readDir(path string) error {
	full, err := filepath.Abs(path)
	if err != nil {
		return err
	}
	entries, err := os.ReadDir(full)
	if err != nil {
		return err
	}
	var list []os.DirEntry
	for _, e := range entries {
		ext := strings.ToLower(filepath.Ext(e.Name()))
		if e.IsDir() || a.dialog == "open" && (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".gif") {
			list = append(list, e)
		}
	}
	sort.SliceStable(list, func(i, j int) bool {
		if list[i].IsDir() != list[j].IsDir() {
			return list[i].IsDir()
		}
		return list[i].Name() < list[j].Name()
	})
	a.dir, a.dirInput, a.entries, a.page = full, full, list, 0
	return nil
}

func (a *app) renderDialog(m *image.RGBA) {
	a.buttons = nil
	fill(m, image.Rect(88, 80, 1112, 790), color.RGBA{211, 220, 233, 255})
	fill(m, image.Rect(92, 84, 1108, 786), white)
	title := "Открыть изображение — PNG / JPEG / GIF"
	if a.dialog == "directory" {
		title = "Выбрать каталог сохранения"
	}
	a.text(m, 110, 118, 18, title, ink)
	a.field(m, image.Rect(110, 140, 925, 176), a.dirInput, 3)
	a.add(m, image.Rect(940, 140, 1088, 176), "Перейти", "browse")
	a.add(m, image.Rect(110, 190, 260, 226), "На уровень выше", "parent")
	a.add(m, image.Rect(938, 190, 1088, 226), "Отмена", "close")
	for row := 0; row < 16; row++ {
		i := a.page*16 + row
		if i >= len(a.entries) {
			break
		}
		e := a.entries[i]
		y := 240 + row*28
		r := image.Rect(110, y, 1088, y+27)
		if row%2 == 0 {
			fill(m, r, color.RGBA{238, 242, 248, 255})
		}
		label := e.Name()
		if e.IsDir() {
			label = "[каталог]  " + label
		}
		if len([]rune(label)) > 95 {
			label = string([]rune(label)[:92]) + "…"
		}
		a.text(m, 122, y+20, 16, label, ink)
		a.buttons = append(a.buttons, button{r, label, fmt.Sprint("entry-", i)})
	}
	a.add(m, image.Rect(110, 708, 240, 744), "Предыдущие", "prev")
	a.add(m, image.Rect(252, 708, 382, 744), "Следующие", "next")
	if a.dialog == "directory" {
		a.add(m, image.Rect(790, 708, 1088, 744), "Выбрать этот каталог", "choose-dir")
	}
	message := "Клик по каталогу открывает его; клик по файлу загружает изображение. Esc — отмена."
	if strings.HasPrefix(a.status, "Ошибка:") {
		lines := wrap(a.status, 120)
		if len(lines) > 0 {
			message = lines[0]
		}
	}
	a.text(m, 110, 770, 14, message, muted)
}

func (a *app) key(e xproto.KeyPressEvent) {
	index := (int(e.Detail) - int(a.minKey)) * int(a.keys.KeysymsPerKeycode)
	if index < 0 || index >= len(a.keys.Keysyms) {
		return
	}
	if e.State&xproto.ModMaskShift != 0 && a.keys.KeysymsPerKeycode > 1 {
		index++
	}
	sym := uint32(a.keys.Keysyms[index])
	if sym == 0xff1b {
		a.dialog = ""
		a.focus = 1
		return
	}
	if sym == 0xff09 {
		if a.dialog != "" {
			a.focus = 3
		} else {
			a.focus = a.focus%2 + 1
		}
		a.selectAll = true
		return
	}
	if e.State&xproto.ModMaskControl != 0 {
		if sym == 'a' || sym == 'A' {
			a.selectAll = true
		}
		return
	}
	var field *string
	switch a.focus {
	case 1:
		field = &a.angle
	case 2:
		field = &a.out
	case 3:
		field = &a.dirInput
	default:
		return
	}
	if sym == 0xff0d {
		action := "all"
		if a.dialog != "" {
			action = "browse"
		}
		if err := a.action(action); err != nil {
			a.status = "Ошибка: " + err.Error()
		}
		return
	}
	if sym == 0xff08 || sym == 0xffff {
		if a.selectAll {
			*field = ""
		} else if len(*field) > 0 {
			_, size := utf8.DecodeLastRuneInString(*field)
			*field = (*field)[:len(*field)-size]
		}
		a.selectAll = false
		return
	}
	ch := rune(0)
	if sym >= 32 && sym < 127 || sym >= 160 && sym <= 255 {
		ch = rune(sym)
	}
	if sym&0xff000000 == 0x01000000 {
		ch = rune(sym & 0xffffff)
	}
	if ch == 0 || len([]rune(*field)) >= 1000 {
		return
	}
	if a.selectAll {
		*field = ""
		a.selectAll = false
	}
	*field += string(ch)
}
```

## Листинг 3.8 — cmd/lab6/main_test.go

```go
package main

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func TestDemoAndBatch(t *testing.T) {
	dir := t.TempDir()
	if err := run([]string{"-mode", "demo", "-out", dir}); err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(dir, "batch")
	if err := run([]string{"-mode", "batch", "-source", filepath.Join(dir, "source.png"), "-out", out}); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"affine.png", "restored.png", "nonlinear.png", "metrics.json"} {
		a, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil {
			t.Fatal(err)
		}
		b, err := os.ReadFile(filepath.Join(out, name))
		if err != nil || !bytes.Equal(a, b) {
			t.Fatal(name, err)
		}
	}
	for _, args := range [][]string{{"-mode", "bad"}, {"-mode", "batch"}, {"-angle", "NaN"}, {"-axis", "bad"}, {"-source", "missing.png"}} {
		if err := run(args); err == nil {
			t.Fatal("bad input accepted", args)
		}
	}
}
```

## Листинг 3.9 — internal/raster/transform_test.go

```go
package raster

import (
	"bytes"
	"image"
	"image/color"
	"math"
	"path/filepath"
	"testing"
)

func pattern(w, h int) *image.RGBA {
	m, _ := New(w, h)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			m.SetRGBA(x, y, color.RGBA{uint8(x % 251), uint8(y % 251), uint8((x*7 + y*3) % 251), 255})
		}
	}
	return m
}

func TestMatrixOrderAndInverse(t *testing.T) {
	for _, axis := range []string{"vertical", "horizontal"} {
		m, err := Variant8(640, 420, 30, axis)
		if err != nil {
			t.Fatal(err)
		}
		inv, err := m.Inverse()
		if err != nil {
			t.Fatal(err)
		}
		for _, p := range [][2]float64{{0, 0}, {300, 200}, {639, 419}, {319.5, 209.5}} {
			x, y := m.Point(p[0], p[1])
			xx, yy := inv.Point(x, y)
			if math.Abs(xx-p[0]) > 1e-10 || math.Abs(yy-p[1]) > 1e-10 {
				t.Fatal("inverse", p, xx, yy)
			}
			// Independently rotate, then reflect, around the exact centre.
			u, v := p[0]-319.5, p[1]-209.5
			c, s := math.Cos(math.Pi/6), math.Sin(math.Pi/6)
			rx, ry := c*u-s*v, s*u+c*v
			if axis == "vertical" {
				rx = -rx
			} else {
				ry = -ry
			}
			if math.Abs(x-(rx+319.5)) > 1e-10 || math.Abs(y-(ry+209.5)) > 1e-10 {
				t.Fatal("wrong order")
			}
		}
	}
	for _, m := range []Matrix{{}, {1, 2, 0, 2, 4, 0}, {math.NaN(), 0, 0, 0, 1, 0}} {
		if _, err := m.Inverse(); err == nil {
			t.Fatal("bad matrix")
		}
	}
}

func TestReflectionRGBAndSizes(t *testing.T) {
	for _, size := range []image.Point{{1, 1}, {2, 3}, {13, 7}, {640, 420}} {
		src := pattern(size.X, size.Y)
		before := append([]byte(nil), src.Pix...)
		for _, axis := range []string{"vertical", "horizontal"} {
			m, _ := Variant8(size.X, size.Y, 0, axis)
			dst, st, err := Warp(src, m)
			if err != nil || st.Outside != 0 || st.Mapped != size.X*size.Y {
				t.Fatal(st, err)
			}
			for y := 0; y < size.Y; y++ {
				for x := 0; x < size.X; x++ {
					u, v := x, y
					if axis == "vertical" {
						u = size.X - 1 - x
					} else {
						v = size.Y - 1 - y
					}
					if dst.RGBAAt(x, y) != src.RGBAAt(u, v) {
						t.Fatal("RGB mismatch", x, y)
					}
				}
			}
			inv, _ := m.Inverse()
			back, _, err := Warp(dst, inv)
			if err != nil || !bytes.Equal(src.Pix, back.Pix) {
				t.Fatal("exact mirror round-trip")
			}
		}
		if !bytes.Equal(before, src.Pix) {
			t.Fatal("source changed")
		}
	}
}

func TestNinetyDegreesAndClipping(t *testing.T) {
	src := pattern(9, 9)
	m, _ := Variant8(9, 9, 90, "vertical")
	dst, st, err := Warp(src, m)
	if err != nil || st.Outside != 0 {
		t.Fatal(st, err)
	}
	for y := 0; y < 9; y++ {
		for x := 0; x < 9; x++ {
			if dst.RGBAAt(x, y) != src.RGBAAt(y, x) {
				t.Fatal("90-degree transpose")
			}
		}
	}
	rect := pattern(73, 39)
	m, _ = Variant8(73, 39, 37, "horizontal")
	dst, st, err = Warp(rect, m)
	if err != nil || st.Outside == 0 || st.Mapped+st.Outside != 73*39 {
		t.Fatal(st, err)
	}
	white := color.RGBA{255, 255, 255, 255}
	count := 0
	for y := 0; y < 39; y++ {
		for x := 0; x < 73; x++ {
			if dst.RGBAAt(x, y) == white {
				count++
			}
		}
	}
	if count != st.Outside {
		t.Fatal("clipping background", count, st)
	}
}

func TestRestoresTransformedRaster(t *testing.T) {
	src := pattern(100, 70)
	r, err := Process(src, 30, "vertical")
	if err != nil {
		t.Fatal(err)
	}
	mae, _ := MAE(src, r.Restored)
	if mae <= 0 {
		t.Fatal("losses were incorrectly hidden")
	}
	// Changing the transformed raster must affect the restored image.
	for i := 0; i < len(r.Affine.Pix); i += 4 {
		r.Affine.Pix[i], r.Affine.Pix[i+1], r.Affine.Pix[i+2] = 200, 10, 80
	}
	inv, _ := r.Matrix.Inverse()
	back, _, err := Warp(r.Affine, inv)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Equal(back.Pix, r.Restored.Pix) {
		t.Fatal("restoration ignores transformed input")
	}
}

func TestExactNonlinearFormula(t *testing.T) {
	for x, want := range map[float64]float64{-64: -1024, -1: -1, 0: 0, 1: 1, 64: 1024} {
		if math.Abs(Power53(x)-want) > 1e-9 {
			t.Fatal(x, Power53(x))
		}
		if math.Abs(Power35(Power53(x))-x) > 1e-10 {
			t.Fatal("inverse power", x)
		}
	}
	for _, size := range []image.Point{{1, 1}, {2, 3}, {33, 17}, {640, 420}} {
		src := pattern(size.X, size.Y)
		dst, st, err := Nonlinear(src)
		if err != nil || st.Outside != 0 {
			t.Fatal(st, err)
		}
		for y := 0; y < size.Y; y++ {
			for x := 0; x < size.X; x++ {
				// Literal pixel coordinates: no unit-interval normalisation allowed.
				u := int(math.Round(math.Pow(float64(x), .6)))
				if dst.RGBAAt(x, y) != src.RGBAAt(u, y) {
					t.Fatal("nonlinear mapping", x, y, u)
				}
			}
		}
	}
}

func TestErrorsAndPNG(t *testing.T) {
	for _, angle := range []float64{math.NaN(), math.Inf(1), 361} {
		if _, err := Variant8(10, 10, angle, "vertical"); err == nil {
			t.Fatal(angle)
		}
	}
	if _, err := Variant8(10, 10, 0, "diagonal"); err == nil {
		t.Fatal("invalid axis")
	}
	if _, _, err := Nonlinear(nil); err == nil {
		t.Fatal("nil")
	}
	if _, err := New(-1, 7); err == nil {
		t.Fatal("invalid canvas")
	}
	if _, err := Decode(bytes.NewBufferString("broken image")); err == nil {
		t.Fatal("corrupt file")
	}
	src := pattern(31, 20)
	path := filepath.Join(t.TempDir(), "a.png")
	if err := Save(path, src); err != nil {
		t.Fatal(err)
	}
	read, err := Load(path)
	if err != nil || !bytes.Equal(read.Pix, src.Pix) {
		t.Fatal("PNG roundtrip", err)
	}
	if err := Save(filepath.Join(path, "bad.png"), src); err == nil {
		t.Fatal("unwritable destination")
	}
	if _, err := Load(path + "missing"); err == nil {
		t.Fatal("missing file")
	}
}
```

## Листинг 3.10 — internal/desktop/desktop_test.go

```go
package desktop

import (
	"bytes"
	"image"
	"image/png"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/jezek/xgb"
	"github.com/jezek/xgb/xproto"
	"graphiclabs/lb6/internal/raster"
)

func TestActionsAndErrors(t *testing.T) {
	a := &app{source: raster.Demo(), angle: "30", axis: "vertical", out: t.TempDir()}
	if err := a.action("restore"); err == nil {
		t.Fatal("restored without affine")
	}
	a.angle = "bad"
	if err := a.action("all"); err == nil {
		t.Fatal("bad angle accepted")
	}
	a.angle = "30"
	if err := a.action("all"); err != nil {
		t.Fatal(err)
	}
	before := append([]byte(nil), a.results.Restored.Pix...)
	// Restoration must use the stored matrix even if un-applied input changes.
	a.angle = "77"
	a.axis = "horizontal"
	if err := a.action("restore"); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(before, a.results.Restored.Pix) {
		t.Fatal("used unsaved UI parameters")
	}
	if err := a.action("save-all"); err != nil {
		t.Fatal(err)
	}
	if err := a.action("demo"); err != nil || a.results.Affine != nil {
		t.Fatal("old results not cleared")
	}
	if err := a.save(1); err == nil {
		t.Fatal("empty result saved")
	}
	if err := a.readDir(filepath.Join(a.out, "missing")); err == nil {
		t.Fatal("bad directory")
	}
}

// This is an actual X11 window test, not a painted mock-up.
func TestNativeWindowWorkflow(t *testing.T) {
	if os.Getenv("DISPLAY") == "" {
		t.Skip("requires X11/Xvfb; run with DISPLAY for native integration")
	}
	dir := t.TempDir()
	input := filepath.Join(dir, "source.png")
	out := filepath.Join(dir, "output")
	src := raster.Demo()
	if err := raster.Save(input, src); err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	if binary := os.Getenv("LAB6_GUI_BINARY"); binary != "" {
		cmd := exec.Command(binary, "-source", input, "-out", out)
		cmd.Env = []string{"PATH=/nonexistent", "DISPLAY=" + os.Getenv("DISPLAY")}
		cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
		go func() { done <- cmd.Run() }()
	} else {
		go func() { done <- Run(src, input, out, 30, "vertical") }()
	}
	c, err := xgb.NewConn()
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	screen := xproto.Setup(c).DefaultScreen(c)
	var win xproto.Window
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) && win == 0 {
		tree, err := xproto.QueryTree(c, screen.Root).Reply()
		if err != nil {
			t.Fatal(err)
		}
		for _, w := range tree.Children {
			p, e := xproto.GetProperty(c, false, w, xproto.AtomWmName, xproto.AtomString, 0, 100).Reply()
			if e == nil && strings.HasPrefix(string(p.Value), "Lab6 -") {
				win = w
				break
			}
		}
		if win == 0 {
			select {
			case err := <-done:
				t.Fatal("window failed", err)
			default:
			}
			time.Sleep(20 * time.Millisecond)
		}
	}
	if win == 0 {
		t.Fatal("window did not appear")
	}
	defer func() {
		atom, _ := xproto.InternAtom(c, false, 16, "WM_DELETE_WINDOW").Reply()
		data := xproto.ClientMessageDataUnionData32New([]uint32{uint32(atom.Atom), 0, 0, 0, 0})
		e := xproto.ClientMessageEvent{Format: 32, Window: win, Data: data}
		xproto.SendEvent(c, false, win, 0, string(e.Bytes()))
		select {
		case err := <-done:
			if err != nil {
				t.Error(err)
			}
		case <-time.After(5 * time.Second):
			t.Error("window did not close")
		}
	}()
	click := func(x, y int) {
		geom, e := xproto.GetGeometry(c, xproto.Drawable(win)).Reply()
		if e != nil {
			t.Fatal(e)
		}
		scale := min(float64(geom.Width)/frameW, float64(geom.Height)/frameH)
		px := int((float64(geom.Width)-frameW*scale)/2 + float64(x)*scale)
		py := int((float64(geom.Height)-frameH*scale)/2 + float64(y)*scale)
		ev := xproto.ButtonPressEvent{Detail: 1, Root: screen.Root, Event: win, EventX: int16(px), EventY: int16(py), SameScreen: true}
		if err := xproto.SendEventChecked(c, false, win, xproto.EventMaskButtonPress, string(ev.Bytes())).Check(); err != nil {
			t.Fatal(err)
		}
	}
	click(100, 98)   // Actual file chooser.
	click(300, 253)  // First entry is the saved source.png.
	click(815, 148)  // All three operations.
	click(1030, 148) // Save all.
	deadline = time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		if _, err := os.Stat(filepath.Join(out, "nonlinear.png")); err == nil {
			break
		}
		time.Sleep(25 * time.Millisecond)
	}
	want, err := raster.Process(src, 30, "vertical")
	if err != nil {
		t.Fatal(err)
	}
	for i, name := range []string{"affine.png", "restored.png", "nonlinear.png"} {
		got, err := raster.Load(filepath.Join(out, name))
		if err != nil {
			t.Fatal("UI did not save", err)
		}
		expected := []*image.RGBA{want.Affine, want.Restored, want.Nonlinear}[i]
		if !bytes.Equal(got.Pix, expected.Pix) {
			t.Fatal("native result differs", name)
		}
	}
	if path := os.Getenv("LAB6_GUI_CAPTURE"); path != "" {
		// Let the final completed paint reach the X server, then read its window pixels.
		time.Sleep(250 * time.Millisecond)
		geom, err := xproto.GetGeometry(c, xproto.Drawable(win)).Reply()
		if err != nil {
			t.Fatal(err)
		}
		pixels, err := xproto.GetImage(c, xproto.ImageFormatZPixmap, xproto.Drawable(win), 0, 0, geom.Width, geom.Height, 0xffffffff).Reply()
		if err != nil {
			t.Fatal(err)
		}
		img := image.NewRGBA(image.Rect(0, 0, int(geom.Width), int(geom.Height)))
		for i := 0; i < len(img.Pix); i += 4 {
			img.Pix[i], img.Pix[i+1], img.Pix[i+2], img.Pix[i+3] = pixels.Data[i+2], pixels.Data[i+1], pixels.Data[i], 255
		}
		f, err := os.Create(path)
		if err != nil {
			t.Fatal(err)
		}
		err = png.Encode(f, img)
		closeErr := f.Close()
		if err != nil || closeErr != nil {
			t.Fatal(err, closeErr)
		}
	}
}
```

# 4 Исходное и преобразованное изображения

Демонстрационный растр 640×420 создан процедурой Demo на Go. Асимметричные дом, дерево, солнце, стрелка, координатная сетка и цветные полосы позволяют различить поворот, отражение и нелинейное растяжение. Это специально построенный тестовый рисунок. Все изображения далее получены готовой программой с углом 30° и отражением относительно вертикальной центральной оси.

Рисунок 3 — Исходное изображение, 640×420 пикселей

![Рисунок 3 — Исходное изображение, 640×420 пикселей](../images/source.png)

Рисунок 4 — Поворот на 30° и отражение относительно вертикальной оси

![Рисунок 4 — Поворот на 30° и отражение относительно вертикальной оси](../images/affine.png)

Положение асимметричных объектов изменилось согласно композиции SᵥR. Белые участки соответствуют отсутствующим отсчётам за границами исходного растра. Выбрано 219 730 пикселей, вне границ оказались 49 070, или 18,2552 % площади.

Рисунок 5 — Обратное аффинное преобразование результата рисунка 4

![Рисунок 5 — Обратное аффинное преобразование результата рисунка 4](../images/restored.png)

После обратного преобразования расположение сохранившихся объектов приближается к исходному. Угловые области не восстановлены; сетка и контуры имеют ступенчатые и локальные повторяющиеся отсчёты. Средняя абсолютная ошибка по всем компонентам RGB составила 20,619777 в шкале 0…255. В расчёт включены все пиксели, в том числе белые области.

MAE = Σ(|R − R₀| + |G − G₀| + |B − B₀|) / (3WH).

Рисунок 6 — Функциональное преобразование i = x′^(5/3), j = y′

![Рисунок 6 — Функциональное преобразование i = x′^(5/3), j = y′](../images/nonlinear.png)

В функциональном результате цветные полосы левой части исходника растянуты с переменным масштабом. Вертикальные координаты не изменены. Отсутствие дома справа объясняется диапазоном выбираемых исходных столбцов 0…48. Проверка сравнила каждый пиксель с источником по формуле round(i^(3/5)), j; несовпадений нет.

Рисунок 7 — Настоящее окно приложения Linux после обработки и сохранения

![Рисунок 7 — Настоящее окно приложения Linux после обработки и сохранения](interface.png)

Снимок получен чтением пикселей окна с X-сервера при интеграционном тесте готовой amd64-сборки. Тест открыл диалог, выбрал файл, нажал выполнение всех операций и сохранение, затем сравнил RGB сохранённых файлов с результатами ядра. Использовался виртуальный X-сервер Xvfb; это запуск приложения, а не макет интерфейса. У дочернего процесса PATH=/nonexistent, поэтому Go и внешние вспомогательные команды для работы недоступны.

## Проверка и запуск

Все 9 тестов успешно завершены, включая интеграционную проверку настоящего окна. Проверены размеры и точность RGB при отражении, порядок матриц, обратная матрица, поворот на 90°, отсечение, чтение преобразованного растра при восстановлении, точная степенная функция, ошибочные параметры и запись PNG. Команда go vet ./... завершилась без замечаний. Протоколы сохранены в validation.

Собраны статические ELF-файлы для Linux amd64 и arm64 с CGO_ENABLED=0. Сборка amd64 запущена как в графическом, так и в консольном режиме без доступного Go. Консольные PNG побайтово совпали с изображениями отчёта. ARM64 проверена по формату ELF и настройкам сборки; выполнение на ARM64 в данной среде не проводилось. Отдельная попытка изоляции в контейнере недоступна из-за ограничений user namespace и не засчитывается как успешный тест.

Преподаватель распаковывает архив, открывает каталог работы и запускает bin/lab6-linux-amd64 в обычном графическом сеансе Linux. При необходимости следует выдать право исполнения: chmod +x bin/lab6-linux-amd64. Для ARM64 используется второй бинарник. Кнопки позволяют открыть изображение, задать угол и ось, выполнить преобразования и сохранить PNG; исходный демонстрационный рисунок доступен сразу после запуска.

Для консольной обработки: ./bin/lab6-linux-amd64 -mode batch -source images/source.png -out output -angle 30 -axis vertical. Результат — affine.png, restored.png, nonlinear.png и metrics.json в выбранном каталоге. Для графического режима: ./bin/lab6-linux-amd64 -source images/source.png. Подробная инструкция и команды повторной сборки приведены в README.md.

# 5 Ответы на контрольные вопросы

## 1. Какие преобразования координат происходят в процессе формирования на поверхности фотоприёмника двумерного изображения трёхмерной сцены?

Сначала пространственные координаты приводятся к системе камеры поворотом и переносом. Центральная перспективная проекция переводит трёхмерную точку (X, Y, Z) в координаты плоскости: x′ = fX/Z, y′ = fY/Z. При выборе физической плоскости позади центра знак определяется направлением оси Z; для виртуальной плоскости перед центром применима приведённая запись. Далее учитываются положение начала координат, масштаб по осям и поворот системы фотоприёмника — плоское аффинное преобразование. В модели методички различаются проективные, аффинные и нелинейные преобразования. Нелинейные функции учитывают, например, радиальную и тангенциальную дисторсию объектива. Дискретизация фотоприёмником переводит непрерывные координаты и интенсивности в растровые отсчёты; её следует отличать от собственно геометрического преобразования. При произвольном наклоне плоскости точное отображение между плоскостями является проективным, а аффинное описание применимо при соответствующих ограничениях или приближении.

## 2. Где физически находится центр проекции при формировании цифрового изображения?

В идеальной модели камеры-обскуры центр проекции находится в отверстии, через которое проходят лучи к фотоприёмнику. Для идеализированного тонкого объектива его связывают с оптическим центром. В реальном составном объективе эффективной точкой наблюдения со стороны сцены служит центр входного зрачка — изображения апертурной диафрагмы через переднюю часть объектива. Фотоприёмник расположен в плоскости изображения и сам центром проекции не является. При геометрической калибровке используют эффективный центр модели центральной камеры.

## 3. Какие из преобразований необратимы и почему?

Проекция трёхмерной сцены на плоскость в общем случае необратима: точки на одном луче дают одинаковые координаты, поэтому глубина теряется. Аффинное преобразование в непрерывной плоскости обратимо при ненулевом определителе; при нулевом определителе оно схлопывает плоскость в прямую или точку, и разные исходные точки совпадают. Нелинейная функция обратима только на области, где она взаимно однозначна: например, x² на всей вещественной оси не различает x и −x. Функция варианта x^(5/3), понимаемая через вещественный нечётный корень, монотонна и имеет обратную x^(3/5). Однако отсечение холстом, округление, уменьшение разрешения и смешивание отсчётов могут сделать цифровую реализацию необратимой даже при обратимой непрерывной геометрии. В нашей работе именно отсечение и дискретная повторная выборка не позволяют точно восстановить исходник.

## 4. Какие эффекты фотошопа реализованы путём преобразования координат?

Преобразование координат лежит в основе перемещения, поворота, зеркального отражения, масштабирования и наклона (скоса), коррекции перспективы, деформации Warp, пластики Liquify и коррекции геометрической дисторсии объектива. Первые перечисленные операции обычно описываются аффинной матрицей; перспектива требует проективной модели; локальные деформации и исправление дисторсии используют нелинейное поле смещений. При формировании результата применяется интерполяция для получения цвета в нецелых координатах. Изменение яркости, контраста или цветового тона при неизменных позициях пикселей относится к преобразованию интенсивности и цвета, а не координат.

## 5. Какие искажения наблюдаются при выполнении обратного аффинного преобразования в этой работе и почему?

В результате рисунка 5 видны белые утраченные области по краям и углам, ступенчатость наклонных контуров, локальное изменение сетки и мелких деталей. При первом повороте и отражении часть координат выходит за фиксированный холст 640×420; соответствующие данные не сохраняются. При обратной операции программа читает именно аффинный растр, поэтому восстановить эти сведения невозможно. Кроме того, два этапа округления к ближайшему пикселю могут выбрать разные отсчёты, повторить одни пиксели и пропустить другие. Ненулевая MAE = 20,619777 характеризует итоговое отличие по всем RGB-компонентам; она не означает ошибку формулы обратной матрицы. Непрерывное преобразование имеет определитель −1 и обратимо, но его дискретная ограниченная холстом реализация теряет информацию.

# Вывод

В ходе выполненной работы, мы освоили навыки обработки растровых изображений с помощью алгоритмических языков программирования путём преобразования координат пикселей.
